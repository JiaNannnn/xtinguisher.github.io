---
title: "bookdown: Easy Book Publishing with R Markdown"
---

Moved to the [about page](/about/).
