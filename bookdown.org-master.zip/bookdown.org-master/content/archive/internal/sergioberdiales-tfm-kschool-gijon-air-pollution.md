---
title: "Gijón Air Pollution - An exercise of visualization and forecasting"
author: "Sergio Berdiales"
date: "2019-01-17T22:40:50Z"
tags: [Visualization, Forecasting, Data Science, Course, Python]
link: "https://bookdown.org/sergioberdiales/tfm-kschool_gijon_air_pollution/"
length_weight: "25.7%"
pinned: false
---

Gijón Air Pollution - An exercise of visualization and forecasting [...] My name is Sergio Berdiales and I am a Data Analyst with more than ten years experience in Customer Experience and Quality areas. If you want to know more about me or contact me you can visit my Linkedin profile or my Twitter account. This is my final project for the Kschool Master on Data Science (8th edition). The main objective of this project is to show I can apply the acquired knowledge during the master’s course in a practical way . The Master on Data Science of Kschool is a 230-hour course which includes Python ...
