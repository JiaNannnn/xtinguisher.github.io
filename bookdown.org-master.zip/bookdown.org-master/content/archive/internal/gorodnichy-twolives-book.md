---
title: "«Two Lives» by Concordia Antarova"
author: "gorodnichy"
date: "2018-06-17T17:07:51Z"
tags: [Translation]
link: "https://bookdown.org/gorodnichy/twolives-book/"
length_weight: "100%"
pinned: false
---

«Two Lives» by Concordia Antarova: text translation and analysis [...] This work presents the working draft of the English translation of the “The Lives” book by Concordia Antarova. Widely known in Russian speaking spheres, and translated into French, this book remains to be largely unknown to English speaking population, despite its significant spiritual importance, comparable to that of “Book of Joy”. While the efforts on translating this book into English continue, here the draft of it is used for Artificial Intelligence (AI) projects, aiming at building the systems for automated analysis ...
