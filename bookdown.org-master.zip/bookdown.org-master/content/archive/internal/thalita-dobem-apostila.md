---
title: "Noções de Inferência no R"
author: "Thalita do Bem Mattos"
date: "2018-03-28T20:02:25Z"
link: "https://bookdown.org/thalita_dobem/Apostila/"
length_weight: "9%"
pinned: false
---

Esta apostila é uma ferramenta de apoio às aulas teóricas de ME319-Noções de Inferência. [...] O objetivo desta apostila é apresentar os conceitos de inferência ministrados em sala de aula na disciplina ME319 - Noções de Inferência de uma forma prática e intuitiva utilizando recursos computacionais como o software R. ME319 - Noções de Inferência - IMECC/UNICAMP Após fazer a instalação do R vamos instalar o RStudio. O RStudio é uma nova interface para o R com diversas propriedade que facilita o uso do ...
