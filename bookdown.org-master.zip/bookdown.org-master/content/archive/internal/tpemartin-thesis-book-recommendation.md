---
title: "圖書推薦系統"
author: "林凱浩"
date: "2018-06-01T08:31:37Z"
tags: [Github]
link: "https://bookdown.org/tpemartin/thesis_book_recommendation/"
length_weight: "4.4%"
pinned: false
---

碩士論文 [...] 電子書網址： Github repo:https://github.com/tpemartin/thesis-book-recommendation bookdown使用者說明 LyX 註冊RSconnect bookdown::publish_book()或bookdown::publish_book(account="帳戶名") ...
