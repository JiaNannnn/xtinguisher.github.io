---
title: "BRAIN-IAC Neuroimaging Protocols"
author: "Naomi J. Goodrich-Hunsaker, Ph.D."
date: "2019-09-18T18:30:45Z"
link: "https://bookdown.org/u0243256/brainiac/"
length_weight: "13.9%"
pinned: false
---

BRAIN-IAC Neuroimaging Protocols [...] This manual contains a general descriptions of all neuroimaging pipelines currently being used to analyze MRI scans. If additional information or further clarification is needed, email me at naomi.hunsaker@utah.edu. ...
