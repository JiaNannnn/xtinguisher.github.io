---
title: "Utah TDS wqTools vignette"
author: "Jake Vander Laan, Utah Division of Water Quality"
date: "2019-03-07T21:36:32Z"
link: "https://bookdown.org/jvander/wqTools-utah-tds-vignette/"
length_weight: "10.4%"
pinned: false
---

Utah TDS wqTools vignette [...] This vignette shows an example of using wqTools functions to extract and analyze statewide patterns of one water quality parameter, total dissolved ...
