---
title: "UPR-PRISE Data Science Workshop 01/26/2019"
author: "Felix E. Rivera-Mariani, PhD"
date: "2019-01-25T13:51:19Z"
tags: [Data Science, Models]
link: "https://bookdown.org/friveram/uprprise_ds_wksp_manual/"
length_weight: "8.5%"
pinned: false
---

This manual is part of data science workshop titled GPS of Data Analytics: Making the Witness (the Data) Confess. The output format for was elaborated with bookdown::gitbook. [...] Welcome to the data science workshop titled The GPS of Data Analytics: Making the Witness (the Data) Confess. In this workshop, sponsored by the University of Puerto Rico Ponce Research Initiative for Scientific Enhancement, students will learn and implement different aspects of data science, from establishing a set of tools necessary to carry out data science to deploying statistical models through coding, ...
