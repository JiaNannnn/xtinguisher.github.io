---
title: "QA of Code"
author: "Joshua Halls"
date: "2019-09-16T10:57:32Z"
link: "https://bookdown.org/joshuah40/qa_code/"
length_weight: "15.4%"
pinned: false
---

This is a draft of QA for Coding guidance [...] ALPHA This is a draft of GSS guidance. This is unpublished and does not represent the views of the ONS or the GSS.  ...
