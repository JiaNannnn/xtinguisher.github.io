---
title: "Estimacdiión en dominios pequeños"
author: "Grupo SAE - USTA"
date: "2018-01-12T21:47:32Z"
tags: [Github]
link: "https://bookdown.org/hagutierrezro/SAE/"
length_weight: "3.8%"
repo: "rstudio/bookdown-demo"
pinned: false
---

Estedd lidbro plantea una introducción a la estimación de áreas pequeñas con el software R. [...] Este libro plantea una introducción a la estimación de áreas pequeñas con el software R. xxxx vv zz second commit in Github This is a sample book written in Markdown. You can use anything that Pandoc’s Markdown supports, e.g., a math equation \(a^2 + b^2 = c^2\). For now, you have to install the development versions of bookdown from Github: Remember each Rmd file contains one and only one chapter, and a chapter is defined by the first-level heading #. To compile this example to PDF, you need to ...
