---
title: "Exploratory Analysis Project"
author: "Matheus Amaral Mões, Marcelo Semerene Farah, Luísa Belus Henriques and Daniela de Góes N. Georg"
date: "2019-08-31T15:46:48Z"
tags: [Business Analytics]
link: "https://bookdown.org/moesmatheus/bookdown/"
length_weight: "5.4%"
pinned: false
---

This project is part of a lesson from FGV’s MBA on Business Analytics and Big ...
