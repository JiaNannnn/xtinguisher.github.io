---
title: "Ecologische waterkwaliteit Botshol"
author: "lauramoria"
date: "2018-10-08T18:48:44Z"
link: "https://bookdown.org/lauramoria/botshol/"
length_weight: "10.5%"
pinned: false
---

Ecologische waterkwaliteit Botshol [...] AGV is als waterbeheerder verantwoordelijk dat de wateren in haar beheergebied voldoen aan de waterkwaliteitsdoelstellingen van de Europese Kaderrichtlijn Water (KRW) en aan doelstellingen die zijn geformuleerd in het Natura2000 beheerplan. Deze richtlijnen hebben als einddoel schoon en gezond water. Met voldoende kranswieren, fonteinkruiden en ...
