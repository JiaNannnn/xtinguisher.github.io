---
title: "Gopnik Guide to Biology"
author: "Paulius Alaburda"
date: "2017-06-26T08:50:47Z"
tags: [Guide, Biology]
link: "https://bookdown.org/Alaburda/BioMasterBook/"
length_weight: "12.1%"
pinned: false
---

Bandymas sukurti lengvą biologijos elektroninę knygą. [...] Internetas Lietuvos švietimo įrankiams kol kas turėjo mažai įtakos. Vietoje popierinės knygutės atsirado elektroninės knygutės, pasiruošti valstybiniams egzaminams atsirado programėlės. Bet šie įrankiai susiję su kontrolės struktūromis sekti moksleivio progresą ir įvertinti, ar jis teisingai pasiruošė egzaminui. Tikra edukacija prasideda ne nuo pažymių ar atsiskaitymo po 12 metų, o pirminio klausimo - kodėl? Pirminė nuostaba, jog aplinka neatitinka mūsų vidinio realybės modelio pastumia imtis veiksmų išsiaiškinti, kur mes klydome ir ...
