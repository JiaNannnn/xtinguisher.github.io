---
title: "Data Analysis and Processing with R based on IBIS data"
author: "Kevin Donovan"
date: "2019-07-11T17:52:29Z"
tags: [Data Analysis, Course, Network]
link: "https://bookdown.org/kdonovan125/ibis_data_analysis_r4/"
length_weight: "41%"
pinned: false
---

Data Analysis and Processing with R based on IBIS data [...] Over the course of my time working with the Carolina Insitute for Developmental Disabilities (CIDD) and the Infant Brain Imaging Study (IBIS) network, I have seen a great interest in learning how to do basic statistical analyses and data processing among the trainees. Specially, there is an interest in learning how to use R, due to its popularity across the sciences and its zero financial cost. As a statistican in training, I feel it is a great benefit for scientists to learn R. It is vital for scientists to understand the ...
