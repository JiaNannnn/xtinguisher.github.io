---
title: "Notes and Codes while Learning R"
author: "Scott Ming"
date: "2016-07-31T01:24:12Z"
tags: [笔记, 数据科学, Github]
link: "https://bookdown.org/scottming/rns/"
length_weight: "12.7%"
repo: "scottming/rns"
pinned: false
---

这里是明生学 R 的笔记。 [...] Bookdown 是个很赞的写作工具，在这里记录一些自己学习 R 与数据科学的笔记，如有错误，欢迎指出。我的 GitHub 地址：https://github.com/scottming ...
