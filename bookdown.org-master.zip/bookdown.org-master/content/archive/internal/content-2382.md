---
title: "Introduktion till R"
author: "Filip Wästberg"
date: "2019-04-24T13:58:06Z"
link: "https://bookdown.org/content/2382/"
length_weight: "27.2%"
pinned: false
---

Det här är ett dokument med kursmaterial till Coops introduktionsworkshop till R [...] I det här dokumentet finns kursmaterial till Coops introduktionskurs till R. Här finner ni en introduktion till R samt de paket som vi kommer att använda. Jag har även lagt till facit för de övningar vi kommer att gå ...
