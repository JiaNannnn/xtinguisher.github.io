---
title: "Papa’s Three Laws"
author: "大鹏&朋友"
date: "2017-07-20T09:17:01Z"
tags: [育儿]
link: "https://bookdown.org/baydap/papasdiary/"
length_weight: "38.4%"
cover: "https://bookdown.org/baydap/papasdiary/images/cover.jpg"
repo: "pzhaonet/papasdiary"
pinned: false
---

This is a selection of a papa’s diary originally posted on my blog. A family’s stories of two children are told. This book is being updated. [...] 我家有两个娃。大的是男孩，生于北京，唤作京生; 小的也是男孩，生于德国，唤作德生。 本书讲述的是我和我的朋友们的育儿和家庭故事。 ...
