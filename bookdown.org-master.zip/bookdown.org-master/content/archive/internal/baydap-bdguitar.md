---
title: "GuitaR Bookdown"
author: "大鹏"
date: "2017-05-25T20:11:40Z"
tags: [数据分析]
link: "https://bookdown.org/baydap/bdguitar/"
length_weight: "6.9%"
cover: "https://bookdown.org/baydap/bdguitar/images/cover.jpg"
repo: "pzhaonet/boookdown-guitar"
pinned: false
---

This is a collection of my favorite songs with guitar chords, produced by bookdown. [...] 最真的梦，就是用R语言的bookdown把R代码、作图、数据分析和吉他谱弄到一起。 啥？弄到一起有什么用？ 呃……容我清清脑子想一想…… 越过下面这座山丘，却发现无人等候…… 终会有一天　把心愿完成　带着你飞奔找永恒 \[\int_0^\infty e^{-x^2} dx=\frac{\sqrt{\pi}}{2}\] 本书的吉他谱，在网页上看不见，只有点击下载pdf才能看见哦。  ...
