---
title: "Studieren und Forschen mit dem Internet"
author: "Peter Baumgartner, Sabine Payr"
date: "2017-10-16T07:53:51Z"
link: "https://bookdown.org/pbaumgartner/wiss-arbeiten/"
length_weight: "40.6%"
repo: "petzi53/wiss-arbeiten"
pinned: false
---

Arbeitsprozesse und Werkzeuge des wissenschaftlichen Arbeitens. Gekürzte Ausgabe aus 2001, aber viele Inhalte noch aktuell. [...] Studieren und Forschen mit dem Internet von Peter Baumgartner & Sabine Payr ist lizenziert unter einer Creative Commons Namensnennung - Weitergabe unter gleichen Bedingungen 4.0 International Lizenz.Über diese Lizenz hinausgehende Erlaubnisse können Sie unter http://peter.baumgartner.name/kontakt erhalten. Studieren und Forschen mit dem Internet ist 2001 beim StudienVerlag herausgekommen und heute vergriffen. Restexemplare können nach wie vor gebraucht über Amazon ...
