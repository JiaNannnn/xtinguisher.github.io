---
title: "Economía Conductual: Fundamentos y Aplicaciones"
author: "BEST: Behavioral Economics & Data Science Team"
date: "2018-12-14T00:33:07Z"
link: "https://bookdown.org/BEST/Economia-Conductual-Fundamentos-y-Aplicaciones/"
length_weight: "6%"
repo: "BESTDATASCIENCE/LIBRO-ECONOMIA-CONDUCTUAL"
pinned: false
---

El mejor libro en español de economía conductual, libre y abierto. [...] Entender el comportamiento de las personas o de la sociedad, es un tema fascinante. Hace algunos siglos atrás, el profeta Isaías escribió: La economía conductual toca este tema, desde una perspectiva cientìfica, apoyado de la psicología y economía. El libro se compone de 4 partes. Parte I cubre la parte introductoria. El capítulo I Adam Smith, Padre de la Economía Conductual, se enfoca en los orígenes de la economía y de la economía conductual, ambos teniendo a Adam Smith como padre de ambos campos de estudio. El ...
