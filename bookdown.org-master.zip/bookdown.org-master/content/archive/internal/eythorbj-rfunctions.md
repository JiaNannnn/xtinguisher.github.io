---
title: "Föll í R - Dæmi"
author: "Eyþór Björnsson"
date: "2017-05-23T22:00:30Z"
tags: [Github, R Markdown]
link: "https://bookdown.org/eythorbj/Rfunctions/"
length_weight: "10.1%"
pinned: false
---

Föll í R - Dæmi [...] Hér eru dæmi um notkun á föllum sem ég hef skrifað og má finna á GitHub. Þetta eru aðallega föll sem spara mikinn tíma við uppsetningu á algengum töflum fyrir vísindagreinar (á sviði læknavísinda) en eru líka hjálpleg til þess að átta sig á fylgni milli mismunandi breyta í gagnasafninu. Þessi síða er búin til með bookdown. Það er frábær pakki sem tvinnar saman R markdown skrár og setur saman í aðgengilegt html-bókarsnið. Í öllum dæmunum er notast við ‘diabetes’ gagnasettið sem er aðgengilegt frá http://biostat.mc.vanderbilt.edu/wiki/Main/DataSets. The data consist of 19 ...
