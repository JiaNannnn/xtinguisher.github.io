---
title: "DJing to Dolphins"
author: "Ian K Salter"
date: "2019-07-17T10:30:18Z"
link: "https://bookdown.org/ianksalter/djing-to-dolphins/"
length_weight: "31.5%"
repo: "ianksalter/djing-to-dolphins"
pinned: false
---

The 2017 tales of a voyage sailing away from Brexit Britain. [...] The tales of a 2017 voyage sailing away from Brexit Britain reflecting on fake news with the help of the philosophies of science and mathematics. To Natalie - for once upon a time, on the banks of the Thames, encouraging me to keep writing. Creative Commons Attribution-NonCommercial-ShareAlike 4.0 International License. © Ian K Salter 2017, 2018, ...
