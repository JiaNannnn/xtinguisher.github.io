---
title: "Building Web Applications with Shiny and SQL Server"
author: "Matthew Sharkey"
date: "2019-04-27T15:44:29Z"
tags: [Web Applications, Shiny, Guide]
link: "https://bookdown.org/msharkey3434/ShinyDB_Book/"
length_weight: "12.7%"
pinned: false
---

A guide to building scalable Shiny Datbase applications [...] This book supplements my presentation at the Omaha R User Group on Thursday, April 4, ...
