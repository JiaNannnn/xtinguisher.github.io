---
title: "Computational Communication Science mit R"
author: "André Calero Valdez"
date: "2018-10-18T18:58:53Z"
link: "https://bookdown.org/andrecalerovaldez/ccs/"
length_weight: "12.4%"
repo: "sumidu/ccs"
pinned: false
---

Dieses Buch befindet sich zur Zeit in Arbeit. [...] Dieses Buch soll einen Überblick über Computer-basierte Methoden der Kommunikationswissenschaft verschaffen und in Form eine Lehrbuchs die wichtigsten Inhalte zusammenfassen. Zu allen Themen, die in diesem Buch bearbeitet werden, gibt es bereits besser geeignete Bücher, die die entsprechenden Theorien, Methoden und Techniken detailliert und ausführlich betrachten. An geeigneter Stelle wird auf diese Quellen verwiesen. Die zentrale Idee hinter diesem Buch ist die Vereinheitlichung des Forschungsprozesses und die digitale Unterstützung durch ...
