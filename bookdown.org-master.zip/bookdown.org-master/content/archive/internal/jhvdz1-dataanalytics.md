---
title: "Data Analytics"
author: "Hans van der Zwan"
date: "2019-09-09T14:59:35Z"
tags: [Course, Data Science]
link: "https://bookdown.org/jhvdz1/dataanalytics/"
length_weight: "100%"
pinned: false
---

Course notes Data Analytics course at The Hague University of Applied Sciences; lecturer J.H. van der Zwan [...] Ismay C. & Kim A. Y. (2019). ModernDive. Statistical Inference for Data Science. https://moderndive.com.
Rumsey D. J. (2010). Statistical Essentials for Dummies. Hoboken: Wiley ...
