---
title: "Shiny Tutorial"
author: "Weicheng Zhu"
date: "2016-05-25T19:26:11Z"
tags: [Shiny, Tutorial]
link: "https://bookdown.org/weicheng/shinyTutorial/"
length_weight: "9.6%"
pinned: false
---

This is a shiny tutorial. [...] Some basic knowlege about the R lanuage is requred. It would be helpful if you have some basic knowlege about HTML, CSS and javascript, but they are not ...
