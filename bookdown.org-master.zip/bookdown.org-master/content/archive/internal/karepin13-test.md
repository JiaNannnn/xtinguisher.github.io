---
title: "3 Dashboard for students | LASI 2019 - Visualization meets Learning Analytics"
author: "karepin13"
date: "2019-08-26T19:17:41Z"
tags: [Visualization]
link: "https://bookdown.org/karepin13/test/"
length_weight: "7.8%"
pinned: false
---

3 Dashboard for students | LASI 2019 - Visualization meets Learning Analytics [...] Let’s construct a prototype of dashboard for one of our students. Discussion:
- How to show student’s perfomance?
- Should we show students their predicted chances for success? On the graph below we show the score for each assesment aside with the average score of other students. We can highlight some of the student’s results which have notable differences with the average score.
Whether it will be usefull or motivating for the student? Maybe we should show that graph to the teacher or assistant (in cases ...
