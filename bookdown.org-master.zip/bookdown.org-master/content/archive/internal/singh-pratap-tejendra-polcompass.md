---
title: "Political Compass in the Random World"
author: "Tejendra Pratap Singh"
date: "2019-09-24T16:16:34Z"
link: "https://bookdown.org/singh_pratap_tejendra/polcompass/"
length_weight: "4.2%"
pinned: false
---

On the robustness of the Political Compass [...] This is to test how the Political Compass Test performs if it is supplied with randomly selected choices. Theoretically, it should gives us zero on the coordinate axis. I will insert the image of the result from the above values inserted in the Political Compass Test. Let’s see what happens. Results can be found at https://www.politicalcompass.org/yourpoliticalcompass?ec=-1.63&soc=-0.87. Although the resulting coordinates are very close to the origin, it looks like the test is made to elicit responses in the third quadrant. I also attach the ...
