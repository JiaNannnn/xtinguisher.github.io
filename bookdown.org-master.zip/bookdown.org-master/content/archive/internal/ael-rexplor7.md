---
title: "Exploration de données avec R"
author: "Anouar El Ghouch"
date: "2019-01-12T14:43:46Z"
link: "https://bookdown.org/ael/rexplor7/"
length_weight: "19.9%"
pinned: false
---

 Ce document est une introduction à l’utilisation du logiciel libre de traitement de données et d’analyse statistique R. il est inspiré de plusieurs sources: Ce document vise à introduire uniquement les notions de base nécessaire à connaitre pour quelqu’un qui découvre le logiciel pour la première ...
