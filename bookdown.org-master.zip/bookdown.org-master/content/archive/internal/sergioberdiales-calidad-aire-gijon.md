---
title: "Calidad del aire en Gijón"
author: "Sergio Berdiales"
date: "2019-05-16T18:20:40Z"
tags: [Data Science]
link: "https://bookdown.org/sergioberdiales/calidad_aire_gijon/"
length_weight: "15.8%"
pinned: false
---

Calidad del aire en Gijón [...] Los objetivos principales de este proyecto son realizar análisis y visualizaciones de los datos de la estaciones oficiales de monitorización de la calidad del aire de la ciudad de Gijón. Este proyecto es hermano de este otro https://bookdown.org/sergioberdiales/tfm-kschool_gijon_air_pollution/, que fue mi trabajo final del Máster de Data Science en Kschool (por eso hay algunas partes del código comentadas en inglés). En él, además de tratar los datos y realizar distintos ejercicios de visualización de los mismos (ver visualizaciones en Tableau Public), realicé ...
