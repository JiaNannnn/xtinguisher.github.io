---
title: "Praktiskā biometrija"
author: "Didzis Elferts"
date: "2016-04-19T05:46:04Z"
link: "https://bookdown.org/delferts/PBB_gramata/"
length_weight: "29.7%"
pinned: false
---

Piemēri darbā ar programmu R, lai risinātu statistikas problēmas bioloģijā. [...] Praktiskā biometrija Šī grāmata ir mans mēģinājums samērā vieglā formā ar minimālu teorijas materiālu sniegt praktiskus padomus statistisko analīžu veikšanā biologiem. Tā kā uzsvars ir likts uz vārdu ‘’praktiski’’, tad lielāko grāmatas daļu sastāda piemēri tam, kā veikt katru no apskatītajiem statistiskajiem testiem. Plašāka teorētiskā pamatojuma iegūšanai noderēs citu autoru darbi. Nenoliedzami nopietnākais darbs latviešu valodā biometrijas jomā ir jāmin Liepa (1974) grāmata, angļu valodā tas būtu kāds no ...
