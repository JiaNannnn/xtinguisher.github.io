---
title: "An approach to identify the sources of low-carbon growth for Europe"
author: "Georg Zachmann, Bruegel gz@bruegel.org, Robert Kalcik, Bruegel robert.kalcik@bruegel.org"
date: "2017-04-21T11:58:41Z"
link: "https://bookdown.org/robertkck/i24c_website/"
length_weight: "10.1%"
cover: "https://bookdown.org/robertkck/i24c_website/images/cover.png"
repo: "robertkck/i24c"
pinned: false
---

This website serves to illustrate the findings of the policy contribution ‘An approach to identify the sources of low-carbon growth for Europe’ and allows a deeper dive into the underlying data. [...] This website serves to illustrate the findings of the policy contribution “An approach to identify the sources of low-carbon growth for Europe” (Zachmann 2016) and allows a deeper dive into the underlying data. The website is focused on presenting figures and deliberately only offers short descriptions and interpretations. The research underlying this report has been financially supported by the  ...
