---
title: "Text as Data para Ciências Sociais"
author: "Davi Moreira"
date: "2019-08-25T20:05:05Z"
tags: [Tutorial]
link: "https://bookdown.org/davi_moreira/txt4cs/"
length_weight: "7.9%"
pinned: false
---

Compilação de métodos e técnicas para análise automatizada de conteúdo [...] A partir da produção de material para o curso Text as Data: análise automatizada de conteúdo que ministrei no MQ-UFMG em 2019 e no artigo que publiquei em coautoria com Maurício Izumi (Izumi and Moreira 2018), esse livro tem como propósito difundir nas ciências sociais e humanidades técnicas e métodos de análise automatizada de conteúdo usando a linguagem R. O principal objetivo do livro é ser tutorial prático de uso e aplicação de técnicas e métodos de análise automatizada de conteúdo na língua portuguesa através da  ...
