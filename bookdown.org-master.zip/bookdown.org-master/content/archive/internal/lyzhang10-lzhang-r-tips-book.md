---
title: "R tips: 16 HOWTO’s with examples for data analysts"
author: "Lingyun Zhang"
date: "2017-08-27T10:35:23Z"
link: "https://bookdown.org/lyzhang10/lzhang_r_tips_book/"
length_weight: "18.7%"
pinned: false
---

R tips: 16 HOWTO’s with examples for data analysts [...]  ...
