---
title: "The Good Loser – Results from Three Survey Experiments"
author: "sveinungarnesen78"
date: "2019-03-28T18:38:49Z"
tags: [Conference]
link: "https://bookdown.org/sveinungarnesen78/Bookdown-goodloser/"
length_weight: "38.4%"
pinned: false
---

The Good Loser – Results from Three Survey Experiments [...] This is the analysis report for the Good Loser Project by Peter Esaiasson, Hannah Werner, and Sveinung Arnesen. The study comprises three survey embedded experiments; one video vignette experiment in Norway, one text vignette experiment in Sweden, and one conjoint experiment in Norway. The study has been presented at the Barcelona-Gothenburg-Bergen workshop on Experiments in Political Science in 2018, and will be presented at the 2019 Conference of the Midwestern Political Science Association in Chicago, USA. About Study I – Swedish  ...
