---
title: "Visualisation with Python"
author: "Jumping Rivers"
date: "2019-09-25T13:33:16Z"
tags: [Python, Machine Learning]
link: "https://bookdown.org/jamie/python_visualisation/"
length_weight: "14.2%"
pinned: false
---

Blah [...] Jumping Rivers is an analytics company whose passion is data and machine learning. We help our clients move from data storage to data insights. Jumping Rivers has delivered quality data insights from day 1. Based in Newcastle and founded in 2016, the company is bringing a fresh approach to the world of data analytics. Jumping Rivers offer a number of training options in R and Python ranging from introductory programming to applied machine learning, automated reporting and app development. We also offer the facility to create bespoke training programs for our clients to make sure ...
