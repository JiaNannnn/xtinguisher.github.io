---
title: "Bayesian Hierarchical Models in Ecology"
author: "Steve Midway"
date: "2019-09-16T13:34:21Z"
tags: [Bayesian, Models, Ecology, Course]
link: "https://bookdown.org/steve_midway/BHME/"
length_weight: "18.5%"
pinned: false
---

This is a book that is build on lectures from a course of the same name. [...] Welcome to Bayesian Hierarchical Models in Ecology. This is an ebook that is also serving as the course materials for a graduate class of the same name. There will be numerous and on-going changes to this book, so please check back. And don’t hesistate to email me if you have questions, comments, or for anything else. To start, let’s calrify the title of this text—it should be Hierarchical Models in Ecology Using Bayesian Inference. A Bayesian Hierarchical Model is more a term of convenience than accuracy, as ...
