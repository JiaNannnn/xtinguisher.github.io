---
title: "Introducción a la Computación con GPUs usando R"
author: "Ronald Gualán Saavedra"
date: "2018-07-14T02:57:13Z"
tags: [GPU, Tutorial]
link: "https://bookdown.org/content/1502/"
length_weight: "12.3%"
repo: "rgualan/R-gpu-workshop"
pinned: false
---

Revisión de conceptos clave sobre la computación GPGPU, y algunos ejemplos simples de uso de librerías aceleradas por GPU [...] Las GPU (Graphics Processing Units; Unidades de Procesamiento de Gráficos) son unidades de procesamiento diseñadas originalmente para procesar gráficos en una computadora rápidamente. Esto se hace teniendo una gran cantidad de unidades de procesamiento simples para cálculos masivamente paralelos. La idea de la computación de propósito general en GPU (GPGPU: general purpose GPU computing) es explotar esta capacidad para el cálculo general. En este tutorial se revisará  ...
