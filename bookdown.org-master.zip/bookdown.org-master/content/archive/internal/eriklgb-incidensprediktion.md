---
title: "Underlagsrapport för En ännu bättre strålbehandling avseende incidens och prevalens av cancer i Västra Sjukvårdsregionen 2016-2030"
author: "Erik Bülow"
date: "2017-06-16T09:05:41Z"
link: "https://bookdown.org/eriklgb/incidensprediktion/"
length_weight: "23.4%"
repo: "rstudio/bookdown-demo"
pinned: false
---

Förutsägelse av framtida förekomst av cancer i Västra Sjukvårdsregionen. [...] Rapporten presenteras i tre format, samtliga med samma text- och bildmässiga innehåll men med något olika tekniska lösningar. Om du läser denna rapports HTML-version så når du övriga format via nedladdningsikonen i sidhuvudet (se figur ...
