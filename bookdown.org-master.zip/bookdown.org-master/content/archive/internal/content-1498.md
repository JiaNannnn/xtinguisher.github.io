---
title: "HPC con R para Investigadores"
author: "Johanna Orellana Alvear - johanna.orellana@ucuenca.edu.ec"
date: "2018-07-13T04:16:41Z"
tags: [HPC]
link: "https://bookdown.org/content/1498/"
length_weight: "17.8%"
pinned: false
---

HPC con R para Investigadores [...] “Programmers waste enormous amounts of time thinking about, or worrying about, the speed of noncritical parts of their programs, and these attempts at efficiency actually have a strong negative impact when debugging and maintenance are considered.” — Donald Knuth. Optimizar código para hacerlo más rápido es un proceso ...
