---
title: "Bookdown"
author: "Arredondo Sánchez Andrea Elizabeth, Vargas Mendoza Ana Luisa"
date: "2019-04-02T12:56:09Z"
tags: [Shiny, R Markdown]
link: "https://bookdown.org/ana_vm/_book/"
length_weight: "8.5%"
pinned: false
---

Yihui Xie es ingeniero de software de RStudio, autor de distintos paquetes como knitr, blogdown, xaringan, tinytex y bookdown. Además, ha colaborado en importantes paquetes como Shiny y RMarkdown. Ha publicado libros como “bookdown: Authoring Books and Technical Documents with R Markdown” del cual nos basaremos para hablar de Bookdown. Bookdown es un paquete de R que nos ayuda a integrar multiples documentos de R Markdown en un solo archivo con formato HTML, PDF,… . Este archivo puede ser un manual de usuario, nuestras notas de estudio e incluso nuestro diario. En él podemos agregar y editar ...
