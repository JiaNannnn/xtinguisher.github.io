---
title: "Ian and Molly’s Odyssey"
author: "Ian K Salter"
date: "2019-01-05T08:39:58Z"
link: "https://bookdown.org/ianksalter/odyssey/"
length_weight: "11%"
repo: "ianksalter/ian-molly-odyssey"
pinned: false
---

The story of a small journey in Autumn 2016. [...] This very short book documents a voyage through France taken in the autumn of 2016. Its two participants head south in their car Dot. The purpose of their journey is ...
