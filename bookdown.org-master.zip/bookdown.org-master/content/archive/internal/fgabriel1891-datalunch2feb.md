---
title: "Data lunch 2feb: The use of Bookdown to write documents and reports"
author: "Gabriel Muñoz"
date: "2017-02-03T20:29:48Z"
tags: [Package, Github]
link: "https://bookdown.org/fgabriel1891/datalunch2feb/"
length_weight: "9.2%"
pinned: false
---

Data lunch 2feb: The use of Bookdown to write documents and reports [...] Make sure you have installed the latest version of R and the Preview Release of RStudio. The following packages should be installed. If you have them already make sure they are updated. The most up to date versions are the “in development” versions from gitHub. Do you have Pandoc installed? RStudio should come along with Pandoc. and latex ? ( if you want to have PDF outputs as well) note that PDF does not allow interactive plots If you do not have latex installed Mac OS X –> MacTeX (http://www.tug.org/mactex/) Linux ...
