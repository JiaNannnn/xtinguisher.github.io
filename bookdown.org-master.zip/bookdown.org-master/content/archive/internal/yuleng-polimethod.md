---
title: "An Introduction to R, LaTeX, and Statistical Inference"
author: "Yuleng Zeng"
date: "2019-07-07T13:39:04Z"
tags: [Course]
link: "https://bookdown.org/Yuleng/polimethod/"
length_weight: "15.3%"
repo: "rstudio/yuleng"
pinned: false
---

An introduction to R for political scientists. [...] This is an introduction to R and Latex. In compiling this documents, several sources have been consulted, including Tim Peterson’s website, Havard’s Math Prefresher, and the course offered by DataCamp. Make sure that you have a laptop throughout this introduction. Install the following applications, if you haven’t done so. Finally, this document is to be used in-class only. As I (will) mention several times, it borrows and merges a lot of resources online. Also, if you see any mistakes or have suggestions, please do shoot me an ...
