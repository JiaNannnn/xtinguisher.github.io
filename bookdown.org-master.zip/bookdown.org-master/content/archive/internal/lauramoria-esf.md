---
title: "Ecologische sleutelfactoren in beeld"
author: "Laura Moria"
date: "2018-12-18T09:22:52Z"
link: "https://bookdown.org/lauramoria/ESF/"
length_weight: "6.2%"
pinned: false
---

De informatie over de huidige situatie en ontwikkelingen van het aquatisch ecosysteem in de regio Amstel, Gooi en Vechtstreek bundelen wij in een zogenaamde Atlas met thema kaarten. Onze doelstellingen en de huidige ecologische kwaliteit zijn verbeeld in de afbeeldingen hieronder. Op een andere pagina (Waterkwaliteit in beeld) staan kaarten van verschillende indicatoren van ecologische kwaliteit voor de Habitatrichtlijn (Natura2000) en de Kaderrichtlijn water. Naast de ontwikkeling van de ecologische toestand wordt ook verbeeld welke processen deze toestand bepalen in het hoofdstuk hieronder ...
