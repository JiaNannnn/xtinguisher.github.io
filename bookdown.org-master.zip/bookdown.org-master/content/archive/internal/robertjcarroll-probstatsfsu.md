---
title: "Probability and Statistics"
author: "Rob Carroll"
date: "2017-08-28T17:57:17Z"
tags: [Statistics, Textbook]
link: "https://bookdown.org/robertjcarroll/ProbStatsFSU/"
length_weight: "4.6%"
pinned: false
---

These are the lecture notes for POS 5737, the introductory probability and statistics class in the graduate program in political science at Florida State University. [...] These are the notes for POS 5737, taught in the Department of Political Science at Florida State University. They freely borrow from several well-known textbooks, including those by Wackerly, Mendenhall, and Scheaffer (2008), DeGroot and Schervish (2012), and Casella and Berger (2002). They also borrow from my own notes as a graduate student when I was taught by Kevin Clarke. Kevin was kind enough to provide his own old ...
