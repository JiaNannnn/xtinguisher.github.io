---
title: "Eagle I.O Consultant Guidelines"
author: "Eagle I.O"
date: "2019-08-02T16:15:21Z"
tags: [Guide]
link: "https://bookdown.org/kulasj/guidelines/"
length_weight: "4%"
pinned: false
---

This is the student guideline manual that describes expectations and responsibilities of Eagle I.O consultants. [...] This manual was written in Bookdown using the GitBook ...
