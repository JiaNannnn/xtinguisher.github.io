---
title: "Meta-Workflow"
author: "Miao YU"
date: "2018-10-15T22:30:26Z"
tags: [Metabolomics, Data Analysis, Github]
link: "https://bookdown.org/yufree/Metabolomics/"
length_weight: "20.3%"
repo: "yufree/metaworkflow"
pinned: false
---

This is a workflow for metabolomics studies. [...] This is an online handout for data analysis in mass spectrometry based metabolomics. It would cover a full reproducible metabolomics workflow for data analysis and important topics related to metabolomics. Here is a list: This is a book written in Bookdown. You could contribute it by a pull request in Github. R and Rstudio are the softwares needed in this ...
