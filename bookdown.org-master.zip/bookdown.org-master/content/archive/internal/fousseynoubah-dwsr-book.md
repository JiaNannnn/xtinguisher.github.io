---
title: "Chapitre 4 Importer des données dans R | Data Science avec R"
author: "Fousseynou Bah"
date: "2019-03-05T18:09:09Z"
tags: [Data Science]
link: "https://bookdown.org/fousseynoubah/dwsr_book/"
length_weight: "26.5%"
pinned: false
---

Chapitre 4 Importer des données dans R | Data Science avec R [...] Dans le flux de travail (workflow) du data scientist, l’importation constitue très généralement le point de départ. Les données ne sont toujours disponibles sous le format qui se prête à l’analyse souhaitée. Elles peuvent exister dans un classeur Excel sous format xls, xlsx ou csv. Elles peuvent aussi se trouver dans une base de données relationnelles, où diverses tables sont connectées entres elles. Elles peuvent même être disponibles sur Internet (page Wikipédia, Twitter, Facebook, etc.) Dans tous les cas, il revient au data  ...
