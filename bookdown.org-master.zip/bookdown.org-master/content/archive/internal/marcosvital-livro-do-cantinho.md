---
title: "R aplicado à Biologia: uma introdução descomplicada e divertida!"
author: "Marcos Vital, do Laboratório de Ecologia Quantitativa da UFAL"
date: "2017-01-07T12:14:35Z"
link: "https://bookdown.org/marcosvital/Livro-do-Cantinho/"
length_weight: "5%"
repo: "rstudio/bookdown-demo"
pinned: false
---

Este é o livro ao vivo do blog Cantinho do R [...] Este material foi construído com a ajuda de muitas pessoas que acreditam no LEQ e em Ciência Livre. Muito obrigado! Para mais material, visite o Cantinho do R Um prefácio da nova apostila do Cantinho do R Viva! Depois de uma longa demora (pelo menos para quem nos acompanha desde o começo), aqui está a nossa nova apostila do Cantinho do R! :D Se você é um recém chegado, acho que eu tenho que começar explicando aqui o que é, pra que serve e de onde nasceu este material, não é? É disso que se trata este primeiro capítulo. Mas não se preocupe, ...
