---
title: "經濟數學程式設計專題"
author: "國立臺北大學 林茂廷老師"
date: "2019-09-19T09:32:48Z"
tags: [Package, Python]
link: "https://bookdown.org/tpemartin/bookdown-programming-for-math-economics/"
length_weight: "11.8%"
pinned: false
---

This is a minimal example of using the bookdown package to write a book. The output format for this example is bookdown::gitbook. [...] 作業 70% 期末專題 30% 學習以下的能力及知識：
基礎Python語法 經濟模型/統計模型（含機器學習）所需面對的數學問題及其求解概念 電腦數值分析求解確定及不確定狀態下的極值問題 本課程雖無電腦程式基礎要求，但建議有基本概念（R或Python均可）。 基礎數學概念：
微分/積分/梯度等 確定狀態下的極值問題：
無限制絛件/有限制條件 基礎統計概念：
隨機變數/估計式/抽樣分配等 不確定狀態下的極值問題：
無限制條件/有限制條件 1. Install Python via Anaconda
連到https://www.anaconda.com/點Download，下載對應自己系統的版本。(請安裝Pyhton 3.X版，其中X為數字  ...
