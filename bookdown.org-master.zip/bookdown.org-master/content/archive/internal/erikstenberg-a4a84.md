---
title: "Lösningar i R till vissa uppgifter från övningskompendierna (samt lite annat kul)"
author: "Erik Stenberg"
date: "2018-04-19T10:15:16Z"
tags: [Guide]
link: "https://bookdown.org/erikstenberg/a4a84/"
length_weight: "13.5%"
repo: "shitoushan/losningar"
pinned: false
---

Lösningar för vissa uppgifter i kursen Statstik A4/A8 [...] Detta dokument är till för dig som läser kursen Statistik A4/A8 och är nyfiken på R. Innehållet är tänkt att förena lite nytta (lösa uppgifter) med nöje (lära dig lite R). Det är inte meningen att detta dokument skall fungera som en heltäckande introduktion till programmeringsspråket R. Det finns mängder av väldigt välskrivna guider online som fokuserar mycket mer på hur språket är uppbygt. Lyckligtvis är R väldigt enkelt att komma igång med, och det krävs inte mycket förståelse för själva språket för att göra enkla beräkningar, ...
