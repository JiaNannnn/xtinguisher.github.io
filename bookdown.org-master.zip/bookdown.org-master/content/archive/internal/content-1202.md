---
title: "Lecture Notes voor Business Process Management (3637)"
author: "B. Depaire"
date: "2018-04-25T20:24:57Z"
link: "https://bookdown.org/content/1202/"
length_weight: "18.4%"
pinned: false
---

Dit zijn de lecture notes van het opleidingsonderdeel Business Process Management [...] Dit document bevatten de lecture notes voor het opleidingsonderdeel Business Process Management (3637), gedoceerd aan de Universiteit Hasselt. Deze lecture notes dienen ter ondersteuning van de colleges en bevatten zowel een “bullet-point” samenvatting van de voornaamste topics alsook een verzameling van bronnen voor verdere verdieping in de ...
