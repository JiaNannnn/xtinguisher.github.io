---
title: "液体活检口袋书"
author: "Dr.Thunder, Ming, Youcai"
date: "2017-06-01T01:26:08Z"
tags: [Liquid Biopsy]
link: "https://bookdown.org/youcai/Liquid_biopsy_PocketBook/"
length_weight: "18.2%"
repo: "OpenGene/PocketBook"
pinned: false
---

Liquid biopsy pocket book (in Chinese), written by Bioinformatics engineers. [...] 海普洛斯推出【液体活检口袋书】专栏，对液体活检进行系统、全面的介绍。每周三更新，向大家介绍关于液体活检的一切。 ...
