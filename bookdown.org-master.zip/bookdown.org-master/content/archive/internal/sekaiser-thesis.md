---
title: "Revealed comparative advantage and network centrality"
author: "Sergej Kaiser"
date: "2017-01-26T12:32:23Z"
tags: [Network Centrality]
link: "https://bookdown.org/sekaiser/Thesis/"
length_weight: "20.3%"
pinned: false
---

Revealed comparative advantage and network centrality ...
