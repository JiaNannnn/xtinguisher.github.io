---
title: "Lecture Notes for Project Management"
author: "B. Depaire"
date: "2019-09-22T19:43:57Z"
tags: [Course]
link: "https://bookdown.org/content/1785/"
length_weight: "9.3%"
pinned: false
---

These are the lecture notes for the course Project Management [...] This document contains the lecture notes for the course Project Management (3897) taught at Hasselt University. Each chapter of this document serves to support the lecture presentations and contains a summary in bullet-point style. We advise students to go throught these lecture notes immediately after the lecture and to add your own notes to this ...
