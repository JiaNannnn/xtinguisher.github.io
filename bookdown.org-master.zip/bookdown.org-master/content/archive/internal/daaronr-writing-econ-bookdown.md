---
title: "Essay, term paper, and dissertation writing for Economics undergraduates (and MSc students)"
author: "David Reinstein"
date: "2019-07-19T11:02:17Z"
tags: [Guide, Package]
link: "https://bookdown.org/daaronr/writing_econ_bookdown/"
length_weight: "5.6%"
repo: "rstudio/bookdown-demo"
pinned: false
---

An interactive guide to doing Economics research, mainly aimed at undergraduates; a work in progress [...] This is a sample book written in Markdown. You can use anything that Pandoc’s Markdown supports, e.g., a math equation \(a^2 + b^2 = c^2\). The bookdown package can be installed from CRAN or ...
