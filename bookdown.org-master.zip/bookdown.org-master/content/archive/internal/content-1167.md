---
title: "Lecture Notes voor Exploratieve en Descriptieve Data Analyse"
author: "B. Depaire"
date: "2018-04-16T22:07:27Z"
link: "https://bookdown.org/content/1167/"
length_weight: "26.7%"
pinned: false
---

Dit zijn de lecture notes van het opleidingsonderdeel Exploratieve en Descriptieve Data Analyse [...] Dit boek bevat de lecture notes voor de cursus “Exploratieve en Descriptieve Data Analyse” (1ste Ba Handelsingenieur/Handelsingenieur in de Beleidsinformatica) aan de Universiteit Hasselt. Het idee van dit document is een begeleidende tekst aan te reiken ter ondersteuning van de slide-decks die gebruikt worden tijdens de hoorcolleges. Deze tekst is “bullet-point” gewijs opgebouwd en helpt het verhaal dat tijdens het hoorcollege wordt verteld terug op te roepen. Daarnaast zal er per hoofdstuk ...
