---
title: "Notes on R for AML100"
author: "Jordan T. Bates"
date: "2017-06-20T18:10:10Z"
tags: [Course, R Markdown]
link: "https://bookdown.org/jtbates/AML100_R/"
length_weight: "4%"
repo: "jtbates/AML100_R"
pinned: false
---

Notes on R for the course AML100 at Arizona State University. [...] These notes introduce the basics of the programming language R as needed for the course AML100. Notes on RStudio and R Markdown are included in ...
