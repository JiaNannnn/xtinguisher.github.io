---
title: "Lab Manual for the Respiratory and Immunology Project and Laboratory Research Team (RIPLRT)"
author: "Authors: The RIPLRT"
date: "2019-09-22T23:57:05Z"
tags: [Guide]
link: "https://bookdown.org/friveram/labmanualriplrt/"
length_weight: "13.8%"
pinned: false
---

This book constitute the lab manual for the RIPL_Effect Research Team (RIPLRT). The output format for this example is bookdown::gitbook. [...] Welcome to the Respiratory and Immunology Project and Laboratory (RIPLRT) at Larkin University College of Biomedical Sciences. If you are reading our lab manual because you recently joined the RIPLRT, welcome! If you are a current member of the RIPLRT, frequently refer to our lab manual to refresh our guidelines, policies, platforms, among others. We also look forward to immerse you in different learning experiences, such as in immunology, respiratory,  ...
