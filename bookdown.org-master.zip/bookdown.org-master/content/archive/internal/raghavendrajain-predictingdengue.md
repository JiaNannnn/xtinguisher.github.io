---
title: "Dengue Forecasting Project"
author: "Raghvendra Jain"
date: "2016-12-15T10:22:45Z"
tags: [Forecasting, Github]
link: "https://bookdown.org/raghavendrajain/predictingdengue/"
length_weight: "12%"
repo: "bookdownDengue"
pinned: false
---

This is a book that contains experiments and results about the predictions of dengue outtbreaks in Thailand. [...] This is a sample book written in Markdown. For now, you have to install the development versions of bookdown from Github:  ...
