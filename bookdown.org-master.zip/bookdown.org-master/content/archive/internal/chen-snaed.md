---
title: "Applied Social Network Analysis in Education"
author: "chen"
date: "2019-04-23T02:25:04Z"
tags: [Network, Education, Course]
link: "https://bookdown.org/chen/snaEd/"
length_weight: "22.3%"
cover: "https://bookdown.org/chen/snaEd/images/cover.png"
repo: "meefen/sna-ed"
pinned: false
---

This is a course handbook written by Bodong Chen for his SNA course at UMN. [...] This site is the course portal of CI 8371 - Applied Social Network Analysis in Education, taught by Prof. Bodong Chen at the University of Minnesota in Spring ’19. Content on this site is actively built and refined throughout the semester. This site or book is licensed under the Creative Commons Attribution-NonCommercial-ShareAlike 4.0 International License. Last update: 2019-04-23  ...
