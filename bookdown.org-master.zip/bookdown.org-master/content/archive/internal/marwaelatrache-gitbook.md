---
title: "Fatal Force Study Group - Shiny App"
author: "marwaelatrache"
date: "2019-07-03T20:22:53Z"
tags: [Shiny, Statistics]
link: "https://bookdown.org/marwaelatrache/gitbook/"
length_weight: "7.5%"
pinned: false
---

Fatal Force Study Group - Shiny App [...] The Fatal Force Study Group \(FFSG\) was founded at the University of Washington \(UW\) by professor Martina Morris. Morris has a strong background in Sociology and Statistics and after joining an activism group called Not This Time she decided to start investigating fatal encounters with police, along with a group of UW undergraduate students. Since then the group has been joined by Professor Ben Marwick, an UW archaeology professor with a strong interest in statistics and R, as well as several more undergraduate students from both UW and neighboring  ...
