---
title: "Data Visualization Project"
author: "Chiayi Yen"
date: "2018-06-17T22:47:04Z"
tags: [Visualization, Market]
link: "https://bookdown.org/cyyen/thesis/"
length_weight: "7.7%"
pinned: false
---

Data Visualization Project [...] This study aims at investigating how the change of information dissemination process would affect the window-dressing behaviors of mutual fund managers. By convention, window-dressing is defined as the portfolio manipulations right before the quarter-end date, when all the fund managers are required to disclosure their holding firms of that date. Over the past decades, technological progresses largely change the way how information disseminates, and these further influence the information flow of capital markets. For example, the implementation of “Electronic ...
