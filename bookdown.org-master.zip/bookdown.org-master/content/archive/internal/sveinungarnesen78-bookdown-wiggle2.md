---
title: "The Status Quo Bias in Referendums"
author: "Sveinung Arnesen, Troy S. Broderstad, Mikael P. Johannesson, Jonas Linde"
date: "2019-02-12T14:24:35Z"
link: "https://bookdown.org/sveinungarnesen78/Bookdown-wiggle2/"
length_weight: "14.9%"
pinned: false
---

This is an analysis report of a comparative conjoint study on the legitimacy of EU referendums. [...] This is the analysis report for the conjoint experiment of the Wiggle room study by Sveinung Arnesen, Troy S. Broderstad, Mikael P. Johannesson, and Jonas Linde. The experiment was fielded in France, Germany, Iceland, Norway, Sweden, and the Netherlands as part of the 2017 European Internet Panel Study (EIPS); a collaboration between six European probability-based online survey panels. The 2017 joint survey wave was fielded in France by the L’ ́etude longitudinale par internet pour les ...
