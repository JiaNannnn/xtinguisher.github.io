---
title: "網頁外掛功能：GA,Share,Comments"
author: "國立臺北大學經濟學系-經濟時事與多媒體出版"
date: "2018-05-17T23:19:19Z"
tags: [Course]
link: "https://bookdown.org/tpemartin/minicourse-webplugins/"
length_weight: "4.7%"
pinned: false
---

迷你課程 [...] 電子書網址：https://bookdown.org/tpemartin/minicourse-webplugins/ 首先你必需： 在Atom: 點privacypolicy.html 將以下兩個訊息換成你的訊息 https://your_website_url your_email ...
