---
title: "Seeing through the developping lens:"
author: "Paul Langard"
date: "2019-05-21T15:38:45Z"
tags: [Network, Models]
link: "https://bookdown.org/content/2589/"
length_weight: "13.2%"
repo: "rstudio/bookdown-demo"
pinned: false
---

Seeing through the developping lens: [...] Through this project, we aim to decipher post-transcriptional regulation network in the developping lens. In the past decades, post-transcriptional gene regulation (PTGR) was shown to be of particular importance in the developping lens. Indeed, the alteration of PTGR network can result in abnormal development of the lens, of the eye. For example, mutations in RNA binding proteins such as Celf1, Stau2, Tdrd7 has been associated to eye’s defects in animal models. mutation in RNA binding protein Tdrd7 was associated with juvenile cataract in human and ...
