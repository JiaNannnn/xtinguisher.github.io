---
title: "Social Advocacy & Ethical Life"
author: "Yuleng Zeng"
date: "2019-09-24T14:10:52Z"
link: "https://bookdown.org/Yuleng/sael200-slides/"
length_weight: "15.1%"
repo: "rstudio/yuleng"
pinned: false
---

This is an introduction to Social Advocacy & Ethical Life (SAEL 200). It is a class I started teaching in Fall 2019, as a member of the Bridge Humanities Corps (BHC) at the University of South Carolina. In compiling this document, I consult a number of online resources. The intention is to record the process of my preparation for this class and help me improve over time. If you see errors, have suggestions, or do not wish your material to be cited here, please do shoot me an ...
