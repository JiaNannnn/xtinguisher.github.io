---
title: "现代科研指北"
author: "于淼"
date: "2019-03-13T15:41:43Z"
link: "https://bookdown.org/yufree/sciguide/"
length_weight: "24.8%"
pinned: false
---

才疏学浅，不知何为真，仅通少错之法，故不敢言南，仅指北。或曰：现代科研挖坑／跳坑指南 ...
