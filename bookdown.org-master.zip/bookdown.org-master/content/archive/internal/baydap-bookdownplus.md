---
title: "R bookdownplus Textbook"
author: "Peng Zhao"
date: "2017-11-01T15:24:37Z"
tags: [Textbook, Tutorial, Package]
link: "https://bookdown.org/baydap/bookdownplus/"
length_weight: "15.5%"
repo: "pzhaonet/bookdownplus-textbook"
pinned: false
---

A tutorial to <code>R bookdownplus</code>, an extension of <code>R bookdown</code> package. This books shows helps you write academic journal articles, guitar books, chemical equations, mails, calendars, and diaries, on the basis of R <code>bookdown</code>. [...] A book titled R bookdownplus Textbook is surely talking about ‘bookdownplus’ (Zhao 2017b), but let’s start with ‘bookdown’ (Xie 2016). ‘bookdown’ is a software package for writing books or documents based on R language (R Core Team 2016) and Markdown syntax. It is something like Microsoft Word, but more elegant, more powerful, and ...
