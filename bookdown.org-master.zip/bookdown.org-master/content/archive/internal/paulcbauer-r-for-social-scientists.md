---
title: "R for Social Scientists"
author: "Paul C. Bauer, Rudolf Farys"
date: "2018-05-10T12:09:51Z"
tags: [Course]
link: "https://bookdown.org/paulcbauer/r_for_social_scientists/"
length_weight: "19.7%"
repo: "rstudio/bookdown-demo"
pinned: false
---

Script for a an R course at the European University Institute. ...
