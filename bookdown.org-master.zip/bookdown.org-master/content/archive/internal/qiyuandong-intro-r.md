---
title: "R 语言入门，给一心只有学习的你"
author: "Chris Qi from Data Maniac"
date: "2018-09-09T01:08:21Z"
tags: [Package]
link: "https://bookdown.org/qiyuandong/intro_r/"
length_weight: "11.2%"
repo: "rstudio/bookdown-demo"
pinned: false
---

This is a minimal example of using the bookdown package to write a book. The output format for this example is bookdown::gitbook. [...] 想直接上手的同学，可以跳过这一部分，从安装软件开始。如果软件已经安装了，可以跳到第二章。对于喜欢把书从头读到未的同学，欢迎从这里开始。 看到这个题目，你以为我会跟你絮絮叨叨讲一个软件的发展史？这种东西听一耳朵就可以了，写出来都浪费纸墨，噢，这是电子书，不用纸也不用墨，但是打字也费劲儿呀。所以在这里，我就做个大概介绍吧： R是一门用于统计计算和作图的语言，由S语言发展而来，以统计分析功能见长。 R 是新西兰的罗斯.伊哈卡 (Ross Ihaka)和罗伯特.金特尔曼（Robert ...
