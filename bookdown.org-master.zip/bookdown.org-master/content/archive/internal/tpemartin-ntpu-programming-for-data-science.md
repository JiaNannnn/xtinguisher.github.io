---
title: "課程大綱 | ntpu-programming-for-data-science.utf8.md"
author: "tpemartin"
date: "2019-06-12T07:03:41Z"
tags: [Course, Data Analysis]
link: "https://bookdown.org/tpemartin/ntpu-programming-for-data-science/"
length_weight: "18.6%"
pinned: false
---

資料科學程式設計（一） [...] 電子書網址：https://bookdown.org/tpemartin/ntpu-programming-for-data-science/電子書加個人註記：https://via.hypothes.is/https://bookdown.org/tpemartin/ntpu-programming-for-data-science/ gitter chatroom: https://gitter.im/ntpuecon/course-program-for-data-science107-2 This course is to build the foundation for being a data scientist–who masters both data analysis and data engineering. There are two programming languages that will be taught through the course: R and Javascript. R will serve as the data analysis backend, while ...
