---
title: "Egils saga Skalla-Grímssonar"
author: "eythorbj"
date: "2017-05-15T17:21:46Z"
tags: [R Markdown]
link: "https://bookdown.org/eythorbj/Egils_saga/"
length_weight: "100%"
pinned: false
---

Egils saga Skalla-Grímssonar [...] Texti Egils sögu var afritaður af vefsíðu The Icelandic Saga Database (sótt 15. maí 2017) og útbúinn fyrir birtingu hér með R markdown og bookdown pakkanum í R. Eyþór Björnsson, 15. maí ...
