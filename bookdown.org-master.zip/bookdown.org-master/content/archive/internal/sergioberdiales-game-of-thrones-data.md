---
title: "Juego de Tronos - Explorando sus datos"
author: "Sergio Berdiales"
date: "2019-05-27T13:13:55Z"
tags: [Github]
link: "https://bookdown.org/sergioberdiales/game_of_thrones_data/"
length_weight: "8.1%"
pinned: false
---

Juego de Tronos - Explorando sus datos [...] El objetivo de este libro de bookdown es simplemente jugar un poco con los datos de la serie de televisión Juego de Tronos (HBO).
Todo el código y los datos empleados se encuentran en este repositorio de Github https://github.com/sergioberdiales/game_of_thrones. Cualquier consulta, queja o sugerencia me la puedes enviar vía twitter twitter.com/SergioBerdiales ...
