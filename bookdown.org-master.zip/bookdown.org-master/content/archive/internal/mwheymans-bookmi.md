---
title: "Book_MI.utf8.md"
author: "mwheymans"
date: "2019-09-22T19:34:30Z"
link: "https://bookdown.org/mwheymans/bookmi/"
length_weight: "100%"
pinned: false
---

 Copyright ©2019 by Heymans and Eekhout All rights reserved. No part of this book may be reproduced or utilized in any form or by any means, electronic or mechanical, including photocopying, recording, or by any information storage and retrieval system, without permission in writing from the ...
