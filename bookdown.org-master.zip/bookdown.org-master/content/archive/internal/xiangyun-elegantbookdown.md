---
title: "Elegant Bookdown Template"
author: "Ethan Deng, Liam Huang, 黄湘云"
date: "2019-05-28T15:24:58Z"
tags: [笔记, Github]
link: "https://bookdown.org/xiangyun/ElegantBookdown/"
length_weight: "9.4%"
repo: "XiangyunHuang/ElegantBookdown"
pinned: false
---

This is a bookdown template based on ElegantBook. The output format for this template is bookdown::gitbook and bookdown::pdf_book. [...] Elegant LaTeX 项目组致力于打造一系列美观、优雅、简便的模板方便用户使用。目前由 ElegantNote， ElegantBook， ElegantPaper 组成，分别用于排版笔记，书籍和工作论文。如果你在使用本模板，推荐最新版本！最新正式版下载地址： Github。本文将介绍本模板的一些设置内容以及基本使用方法。如果您有其他问题，建议或者意见，欢迎在 Github 上给我们提交 issues 或者邮件1联系我们。最近我们新建了一个 QQ 用户交流群（Q ...
