---
title: "R for MSc DH/RSHR/Epi"
author: "Daniel J Carter"
date: "2019-09-24T21:44:30Z"
tags: [Course]
link: "https://bookdown.org/danieljcarter/r4epi/"
length_weight: "15.5%"
pinned: false
---

R for MSc DH/RSHR/Epi [...] Welcome to the two day Introduction to R for MSc Epi and MSc RSHR. Before you attend the course, you will need to ensure you have your own R setup on your computer. The getting started page will instruct you how to do that. Please do this as early as possible before the course to ensure that you can get help if you encounter any issues. How to interact with this course: Course materials come in three flavours. First, there is the Bookdown file you are reading right now in your web browser - this contains all the code, output, exercise solutions (after the course is  ...
