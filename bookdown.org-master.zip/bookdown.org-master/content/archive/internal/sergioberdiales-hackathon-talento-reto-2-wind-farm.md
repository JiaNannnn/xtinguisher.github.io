---
title: "Hackathon Talento - Reto 2 - Wind Farm"
author: "Sergio Berdiales, Javier Campos y Manuel Antonio García"
date: "2019-06-21T07:57:01Z"
tags: [Machine Learning]
link: "https://bookdown.org/sergioberdiales/hackathon_talento_reto_2_wind_farm/"
length_weight: "12.9%"
pinned: false
---

Hackathon Talento - Reto 2 - Wind Farm [...] Este notebook nace de nuestra participación el 4 de junio de 2019 como equipo en el Hackathon de Machine Learning organizado por Talento Corporativo y patrocinado por EDP, El Comercio, Clustertic y BigML. La competición consistió en el planteamiento de un par de retos de Machine Learning basados en datos de EDP y en los que había que utilizar la herramienta BIGml para ejecutar los modelos. El contenido de este notebook corresponde a la realización del segundo reto, cuyo planteamiento se describe en el apartado uno. Durante la competición la mayor ...
