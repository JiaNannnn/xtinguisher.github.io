---
title: "R Powered Web Applications with Shiny"
author: "Zev Ross (with Andrew Clark)"
date: "2016-11-08T18:23:28Z"
tags: [Web Applications, Shiny, Package]
link: "https://bookdown.org/aclark/zevRossShinyBook/"
length_weight: "5.3%"
pinned: false
---

R Powered Web Applications with Shiny [...] This is a book version, transcribed by Andrew Clark using RStudio’s bookdown package, of an extensive blog post by Zev Ross. The book version has the advantage of being available in several formats, more easily updated and downloadable. However, for an interactive version refer to the above mentioned blog ...
