---
title: "YaRrr! The Pirate’s Guide to R"
author: "Nathaniel D. Phillips"
date: "2018-01-22T17:17:55Z"
tags: [Guide]
link: "https://bookdown.org/ndphillips/YaRrr/"
length_weight: "100%"
cover: "https://bookdown.org/ndphillips/YaRrr/images/YaRrr_Cover.jpg"
repo: "ndphillips/ThePiratesGuideToR"
pinned: false
---

An introductory book to R written by, and for, R pirates [...] The purpose of this book is to help you learn R from the ...
