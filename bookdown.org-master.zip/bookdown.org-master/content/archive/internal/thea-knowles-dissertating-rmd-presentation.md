---
title: "Dissertating with RMarkdown and Bookdown | dissertating_rmd_presentation.utf8.md"
author: "thea_knowles"
date: "2019-04-27T03:58:26Z"
tags: [Tutorial]
link: "https://bookdown.org/thea_knowles/dissertating_rmd_presentation/"
length_weight: "13.4%"
pinned: false
---

A preliminary tutorial led by Thea Knowles for the R-Ladies #LdnOnt workshop series Last updated: ...
