---
title: "Comparing Social Dynamics of a Rental and Purchased Block"
author: "Jolene Quek"
date: "2018-12-13T11:46:59Z"
link: "https://bookdown.org/jolene16quek/Data_Analysis/"
length_weight: "16.8%"
repo: "rstudio/bookdown-demo"
pinned: false
---

Comparing Social Dynamics of a Rental and Purchased Block [...]  ...
