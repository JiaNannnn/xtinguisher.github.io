---
title: "기초통계 개념정리"
author: "김진섭"
date: "2017-01-29T07:46:20Z"
tags: [Statistics]
link: "https://bookdown.org/mathemedicine/Stat_book/"
length_weight: "14.7%"
repo: "rstudio/bookdown-demo"
pinned: false
---

This is a basic statistics book written by JSKIM. [...] This is a basic statistics book written by Jinseob ...
