---
title: "2 Datenherkunft | Making maps with R"
author: "Nico Hahn"
date: "2019-09-12T11:45:07Z"
tags: [Package]
link: "https://bookdown.org/nico_hahn_1996_nh/making_maps_with_r/"
length_weight: "31.2%"
repo: "rstudio/bookdown-demo"
pinned: false
---

This is a minimal example of using the bookdown package to write a book. The output format for this example is bookdown::gitbook. [...] Ein Großteil der Daten, die in dieser Arbeit verwendet wurden, stammen aus OpenStreetMap. Je nach Größe wurden diese entweder mit der beigefügten OSM-App erstellt, oder von https://www.geofabrik.de/ heruntergeladen. Bei Zweiterem wurden die Datensätze mit den command line Tools osmconvert und osmfilter in ein sinnvolles Format konvertiert und gefiltert. Danach war nocheinmal eine weitere Transformation in das GEOJSON Format nötig, wofür das NodeJS Package ...
