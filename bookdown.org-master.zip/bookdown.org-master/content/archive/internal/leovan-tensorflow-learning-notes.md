---
title: "TensorFlow 学习笔记"
author: "Leo Van | 范叶亮"
date: "2018-08-19T08:05:34Z"
tags: [笔记]
link: "https://bookdown.org/leovan/TensorFlow-Learning-Notes/"
length_weight: "30.6%"
repo: "leovan/TensorFlow-Learning-Notes"
pinned: false
---

TensorFlow 学习笔记 [...] 本作品是针对 Tensorflow 深度学习框架的学习笔记，参考的相关资料包括： 本作品使用 R 语言的 Bookdown 扩展包构建，在线版本托管在 https://bookdown.org/leovan/TensorFlow-Learning-Notes ，离线版本请访问托管网站下载。 本作品中使用的部分图标来自 Papirus 图标集。 本作品编译的 PDF 采用 Chapman & Hall 出版社提供的 LaTeX 模板 krantz.cls，英文衬线字体采用 Alegreya，英文无衬线字体采用 Helvetica，中文衬线字体采用 Source Han Serif SC，中文无衬线字体采用 Source Han Sans SC，中文斜体字体采用 Kaiti SC，中英文等宽字体采用 Sarasa Mono SC，数学公式字体采用 Latin Modern Math。 本作品采用  ...
