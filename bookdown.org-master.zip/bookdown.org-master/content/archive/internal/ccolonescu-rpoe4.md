---
title: "Principles of Econometrics with R"
author: "Constantin Colonescu"
date: "2016-09-01T14:36:38Z"
tags: [Econometrics, Guide, Statistics]
link: "https://bookdown.org/ccolonescu/RPoE4/"
length_weight: "100%"
repo: "ccolonescu/RPoE"
pinned: false
---

This is a beginner’s guide to applied econometrics using the free statistics software R. [...]  ...
