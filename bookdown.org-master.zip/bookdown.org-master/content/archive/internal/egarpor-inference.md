---
title: "A First Course on Statistical Inference"
author: "Isabel Molina Peralta and Eduardo García Portugués"
date: "2018-11-21T18:03:54Z"
tags: [Course, Statistics, Data Science]
link: "https://bookdown.org/egarpor/inference/"
length_weight: "39.8%"
pinned: false
---

<p>Notes for Statistical Inference. MSc in Statistics for Data Science. Carlos III University of Madrid.</p> [...] Definition 1.1 (Random experiment) A random experiment is an experiment with the following properties: The following concepts are associated with a random experiment: Example 1.1 The next experiments are random experiments: A probability function is defined as a mapping of subsets (events) of the sample space \(\Omega\) to elements in \([0,1]\). Therefore, it is convenient to count on a “good” structure for these subsets, which will provide “good” properties to the probability ...
