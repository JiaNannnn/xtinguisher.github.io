---
title: "现代统计图形"
author: "谢益辉, 黄湘云, 赵鹏"
date: "2019-09-15T00:44:28Z"
link: "https://bookdown.org/xiangyun/msg/"
length_weight: "100%"
repo: "XiangyunHuang/MSG-Book"
pinned: false
---

现代统计图形书稿 [...] 本书写作过程中收到来自 Song Li、 JackieMe 的贡献，在此表示感谢，我们欢迎更多的人参与改进本书。 本书搬迁过程中更新、替换了原稿中的很多代码，现在与本书配套的 R 软件版本是 R Under development (unstable) (2019-09-02 r77130)，我们同时也在 R 版本 3.6.1 中完成测试。为方便读者复现本书中的计算结果和统计图形，同时也为了方便在 Travis 上自动测试贡献者提交的 PR 和自动部署每次提交的修改，本书的运行环境已经被打包成 Docker 镜像，托管在 Docker Hub 上，镜像地址是 https://hub.docker.com/r/xiangyunhuang/msg-book， 读者可从 Docker Hub 上下载，也可根据目录 docker/ 下的 Dockerfile 本地构建。 ...
