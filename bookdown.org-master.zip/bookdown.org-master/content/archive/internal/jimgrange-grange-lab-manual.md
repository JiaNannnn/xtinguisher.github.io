---
title: "Grange-Lab Manual"
author: "Jim Grange"
date: "2018-10-01T08:55:11Z"
link: "https://bookdown.org/JimGrange/Grange-lab-manual/"
length_weight: "5.4%"
pinned: false
---

The Grange-Lab Manual provides information on all you want (or need) to know about working in the Grange Lab. [...]  ...
