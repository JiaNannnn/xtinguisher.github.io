---
title: "Proyecto Final: Suicidios en México y EU"
author: "Chávez Mañón Tania Nayeli, Mendoza Suárez Brenda Grisel, Vargas Mendoza Ana Luisa"
date: "2019-06-03T15:28:36Z"
link: "https://bookdown.org/ana_vm/proyecto_final_dc/"
length_weight: "23.4%"
pinned: false
---

Proyecto Final: Suicidios en México y EU [...] La motivación de este proyecto es conocer cuáles podrían ser los factores más significativos que llevan a una persona al suicidio para poder prevenirlo. Country: País. Categorías: Mexico, United States Year: Año. Categorías: 1985:2015 Sex: Género. Categorías: female, male Age: Edad. Categoriías: 5-14 years, 15-24 years, 25-34 years, 35-54 years, 55-74 years, 75+ years Suicides: Número de suicidios. Population: Población. HDI: Human development index (Índice de Desarrollo Humano) GDP_PP: Gross domestic product per Capita (Producto Interno Bruto) ...
