---
title: "Pursuing Truth: A Guide to Critical Thinking"
author: "Randy Ridenour"
date: "2019-01-22T21:19:21Z"
tags: [Guide, Textbook, Course, Market]
link: "https://bookdown.org/rlridenour/ct-text/"
length_weight: "24.5%"
cover: "https://bookdown.org/rlridenour/ct-text/images/ct-text-cover.png"
repo: "rlridenour/ct-text"
pinned: false
---

This is a textbook for use in undergraduate critical thinking courses. [...] This is a textbook written primarily for my students in PHIL 1502: Critical Thinking, at Oklahoma Baptist University in Shawnee, Oklahoma. There are many good textbooks for critical thinking on the market today, so why write another one? First, all of those books were written for someone else’s course. None cover all of the topics that I would like to cover in class. Second, as I’m sure any student can attest to, textbooks are remarkably expensive, to the point that most of the world’s population cannot afford access  ...
