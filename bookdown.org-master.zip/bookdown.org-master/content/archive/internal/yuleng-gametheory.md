---
title: "An Introduction to Game Theory"
author: "Yuleng Zeng"
date: "2019-09-04T14:24:46Z"
tags: [Course, Models]
link: "https://bookdown.org/Yuleng/gametheory/"
length_weight: "7.8%"
repo: "rstudio/yuleng"
pinned: false
---

This is an introduction to Game Theory. The project started when I sat in on Tobias Heinrich’s class (POLI 725: International Conflict) in Fall 2019. I was given the opportunity to provide an introduction to basic game theory concepts and methods. Thank again to Toby for the trust and the opportunity. My intention is to build upon the short introduction and potentially expand it into course, with a heavy focus on models used in International Relations. If you have suggestions or find any errors, please do shoot me an ...
