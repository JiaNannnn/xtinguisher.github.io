---
title: "ABJ Syllabus"
author: "Associação Brasileira de Jurimetria"
date: "2017-10-23T19:12:05Z"
link: "https://bookdown.org/fcorrea/bookdown/"
length_weight: "5.4%"
pinned: false
---

A track of papers we read and papers we collect to read in future. [...] Para que o seu bookdown funcione tanto na web quanto no pdf, você deve evitar usar marcadores que dependem do contexto. Para fazer citações você deve usar (Weinstein 1997) ou Weinstein (1997). Isso também funciona pra pacotes (R Core Team 2017) ou R Core Team (2017). Para criar uma figura, é preferível que você use o print padrão do knitr. A label do gráfico será fig:label-do-chunk. Você pode citar fazendo 1.1. Se você precisar importar uma imagem de fora do R, é melhor que você faça ![](), a despeito do que diz o Yihui.  ...
