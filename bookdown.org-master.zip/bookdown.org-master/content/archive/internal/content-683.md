---
title: "R語言套件之道"
author: "Cheng-Chung Li"
date: "2017-07-04T12:05:33Z"
tags: [Package, 臺灣, Github]
link: "https://bookdown.org/content/683/"
length_weight: "3.7%"
repo: "askia318/RPackagesBook"
pinned: false
---

寫這本書有幾個原因，除了將自己對於R語言所學做一個整理之外，還希望能讓更多人將自己製作的R functions包裝成符合CRAN規定的R packages, 放到網路上讓大家共享。其實國內R語言的高手很多，但是卻很少人知道如何將寫好的functions包成套件，而國內的參考資料也不多。因此頂多只能在公司內部分享，這實在是很可惜的事情。 我也希望藉由這樣的資料，讓臺灣的高手們被世界看到，一起為R語言貢獻一份心力。 [...] This is a sample book written in Markdown. You can use anything that Pandoc’s Markdown supports, e.g., a math equation \(a^2 + b^2 = c^2\). For now, you have to install the development versions of bookdown from Github: Remember each Rmd file contains one ...
