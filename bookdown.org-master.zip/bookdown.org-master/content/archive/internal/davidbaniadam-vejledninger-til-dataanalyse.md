---
title: "Notes on Dataanalysis"
author: "David"
date: "2019-09-03T11:20:46Z"
link: "https://bookdown.org/davidbaniadam/vejledninger_til_dataanalyse/"
length_weight: "12.8%"
repo: "davidbaniadam/vejledninger"
pinned: false
---

Kommer senere [...] This “book” is a collection of different notes written for myself and my colleagues and is a work-in-progress and updated 2019-09-03. One chapter is written in ...
