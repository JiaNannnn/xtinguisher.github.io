---
title: "A list of R conferences and meetings"
author: "csgillespie"
date: "2016-12-21T14:29:54Z"
tags: [Conference, Data Science]
link: "https://bookdown.org/csgillespie/meetingsR/"
length_weight: "7.7%"
repo: "jumpingrivers/meetingsR"
pinned: false
---

A list of R conferences and meetings. [...] This site attempts to list R conferences and local useR groups. Please feel free to add any missing group or conference. In particular, most of the associated twitter names are missing. There are currently 263 R user groups and events. To propose a change, just click the pencil icon in the top left hand corner. We also maintain a corresponding list of Data Science conferences and events. The html files for this document live in the docs/ directory of the repository. Travis creates the html files from the .Rmd files and commits them to the docs/ ...
