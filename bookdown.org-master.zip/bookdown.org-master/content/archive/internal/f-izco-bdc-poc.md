---
title: "Base de datos corporativa de personas"
author: "Fernando Izco"
date: "2018-11-27T09:27:39Z"
link: "https://bookdown.org/f_izco/BDC-POC/"
length_weight: "23.3%"
pinned: false
---

Documentación de la prueba de concepto de la base de datos corporativa de personas [...] Este documento describe principalmente la prueba de concepto ejecutada como parte del estudio de viabilidad 22173 EV - Base de datos corporativa de personas Este primer capítulo es un resumen ejecutivo. En caso de querer profundizar más sin perderse en detalles técnicos, consultar también el capítulo 2, ‘Concepto de Solución’. Los demás capítulos describen la prueba de concepto, con el detalle técnico de la implementación. Atariak eta Ezagutza Kudeatzeko Atala / Sección de Portalización y Gestión del ...
