---
title: "An Introduction to Acceptance Sampling and SPC with R"
author: "John Lawson"
date: "2019-08-07T19:42:11Z"
tags: [Statistics]
link: "https://bookdown.org/lawson/an_introduction_to_acceptance_sampling_and_spc_with_r10/"
length_weight: "40.5%"
repo: "rstudio/bookdown-demo"
pinned: false
---

The output format for this book is bookdown::gitbook. [...] This e-book was written for Stat 462 (Quality Control)(see Description) taught in the Statistics Department at Brigham Young University. It is free to read online here, and is licensed inder the Creative Commons Attribution-NonComercial-ShareAlike 4.0 International License (http://creativecommons.org/licenses/by-nc-sa/4.0/) One of the objectives of Stat 462 is to prepare students to pass the ASQ Certified Quality Process Analyst Exam. The book The Certified Quality Process Analyst Handbook by (Christensen, Betz, and Stein 2013) will ...
