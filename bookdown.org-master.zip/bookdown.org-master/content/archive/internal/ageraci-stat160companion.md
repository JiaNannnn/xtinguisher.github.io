---
title: "STAT160 R/RStudio Companion"
author: "Statistics/Data Science at St. John Fisher College"
date: "2019-06-27T16:38:53Z"
tags: [Data Science, Textbook, Course]
link: "https://bookdown.org/ageraci/STAT160Companion/"
length_weight: "16.5%"
pinned: false
---

Companion document to Introduction to Statistical Investigations using R/RStudio. [...] This companion is for use in STAT160 (Introduction to Data Science). The textbook for the course is Introduction to Statistical Investigations (Tintle et. al). Through in-class and home work assignments, students will learn to use R and RStudio. In this companion, we will review the commands and functions students will need to perform statistical analysis and generate statistical ...
