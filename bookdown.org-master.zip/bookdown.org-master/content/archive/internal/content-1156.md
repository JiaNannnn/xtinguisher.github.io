---
title: "Lecture Notes voor Beleidsinformatica"
author: "B. Depaire"
date: "2019-06-01T11:44:23Z"
link: "https://bookdown.org/content/1156/"
length_weight: "30.4%"
pinned: false
---

Dit zijn de lecture notes van het opleidingsonderdeel Beleidsinformatica [...] Dit document bevatten de lecture notes voor het opleidingsonderdeel Beleidsinformatica (3512), gedoceerd aan de Universiteit Hasselt. Ieder hoofdstuk dient ter ondersteuning van een van de hoorcolleges en bevat zowel een samenvatting in “bullet-point” stijl alsook een verzameling bronnen op basis waarvan het hoorcollege is opgebouwd. We raden aan om deze lecture notes steeds kort na het hoorcollege door te nemen en aan te vullen met je eigen notities uit het college. Ook raden we aan de bronnen te raadplegen voor ...
