---
title: "Lokal lagring og bruk av sensitive data"
author: "Are Edvardsen, SKDE"
date: "2017-08-31T12:50:05Z"
link: "https://bookdown.org/areedv/docSens/"
length_weight: "8.3%"
cover: "https://bookdown.org/areedv/docSens/images/logo.svg"
pinned: false
---

Veiledning i installasjon og bruk av VeraCrypt for sikker lagring og sletting av data ved Senter for klinisk dokumentajson og evaluering (SKDE), Helse Nord RHF. [...] Analyse av sensitive og tidsavgrensede data inngår som en del av de praktiske oppgaven SKDE har. Egenskapene til slike data vil typisk være at de kun skal nås av en begrenset og definert gruppe av brukere samt at de effektivt må kunne slettes ved gyldighetsperiodens utløp. Dette gir noen spesielle utfordringer når brukere samtidig skal kunne arbeide effektiv og dele slike data seg imellom. Typisk for analysevirksomhet er også at  ...
