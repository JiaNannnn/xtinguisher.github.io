---
title: "R for Statistics in EPH"
author: "Daniel J Carter"
date: "2019-09-25T09:49:47Z"
tags: [Statistics]
link: "https://bookdown.org/danieljcarter/r4steph/"
length_weight: "7.9%"
pinned: false
---

R for Statistics in EPH [...] Welcome to R for STEPH. This ‘book’ offers the chance to supplement your learning in Stata by conducting the computer practical sessions in R. By the end of this book, you will have enough proficiency in R to carry out a number of basic analyses and understand principles that will allow you to program more complex analyses. Any questions about the content in this book can be directed to Daniel Carter via email or via Twitter if you’re into that sort of thing. There is also the invaluable resource that is Stack Exchange. Chances are high that if you’re running ...
