---
title: "From my lovers and others. (Letters from 2013-2014)"
author: "Carlos Alcalá"
date: "2019-03-25T10:00:30Z"
link: "https://bookdown.org/content/2423/"
length_weight: "7.7%"
repo: "rstudio/bookdown-demo"
pinned: false
---

This is a compendium of the letters written, sent and received during October 2013 until September 2014. [...] Memory, knowledge, lives, even identities, all is distributed. We are socially fragmented. It could be used as an argument for a non-local consciousness theory. Therefore, with this text, I am just trying to compile pieces of what I have been in order to know a bit better what I am know. I have been told in the past that there is wisdom in the text that I wrote, and I am certainly sure that there is wisdom in the texts that I received. I hope you find something that makes your life ...
