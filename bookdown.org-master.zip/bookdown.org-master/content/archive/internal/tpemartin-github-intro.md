---
title: "Github 介紹"
author: "林茂廷老師"
date: "2017-12-30T03:32:14Z"
tags: [Github]
link: "https://bookdown.org/tpemartin/github_intro/"
length_weight: "3.6%"
pinned: false
---

Github 介紹 [...] 這裡我們用非程式設計者懂的說法來解釋，故不符合它們原始的完整定義。 Github.com: 一個【雲端空間】讓你儲存備份用 Github Desktop: 安裝在你電腦上的【備份小精靈】，透過他，你可以選擇將某個資料匣裡的東西備份在自己電腦，或進一步備份在Github.com雲端空間。 我們先假設你已經在Github.com（以下簡稱.com）註冊了一個帳號，也在你電腦安裝了Github Desktop（以下簡稱Desktop），並把Desktop設定好可以和你的.com帳號連結。 ...
