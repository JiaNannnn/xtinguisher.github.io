---
title: "R para principiantes"
author: "Juan Bosco Mendoza Vega"
date: "2018-08-27T00:38:40Z"
link: "https://bookdown.org/jboscomendoza/r-principiantes4/"
length_weight: "33.5%"
cover: "https://bookdown.org/jboscomendoza/r-principiantes4/images/r-principiantes-cover.png"
repo: "jboscomendoza/r-principiantes-bookdown"
pinned: false
---

Un libro introductorio a R, dirigido a personas sin experiencia previa con lenguajes de programación. [...] Propósito del libro R para principiantes pretende ser un materal introductorio al lenguaje de programación R, dirigído a personas que nunca han usado R o ningún otro lenguaje de programación, ni tiene conocimiento previo de probabilidad y estadística. Este libro tiene como propósito que adquieras los fundamentos del uso de R como un lenguaje de programación, desde sus conceptos más elementales, hasta la definición de funciones y generación de gráficos. No son objetivos de este libro que  ...
