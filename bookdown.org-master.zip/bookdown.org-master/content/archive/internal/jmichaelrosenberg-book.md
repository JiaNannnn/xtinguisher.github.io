---
title: "Data Science in Educational Research"
author: "Joshua M. Rosenberg"
date: "2017-07-30T18:15:03Z"
tags: [Data Science, Education, Tutorial]
link: "https://bookdown.org/jmichaelrosenberg/book/"
length_weight: "6.4%"
repo: "jrosen48/dser"
pinned: false
---

This is an introduction and tutorial for data science in educational research. ...
