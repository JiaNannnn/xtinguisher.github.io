---
title: "Dokumentasjon av utdanningsfaglig kompetanse"
author: "Tormod Bøe Førsteamanuensis"
date: "2019-08-05T12:45:25Z"
link: "https://bookdown.org/content/2816/"
length_weight: "9.9%"
pinned: false
---

Dokumentasjon av utdanningsfaglig kompetanse [...] I kapitlene indikerer
>
at teksten er hentet fra “Dokumentasjonskrav fra UiO”. https://www.uio.no/om/organisasjon/utvalg/utdanningskomiteen/moter/2018/mote-nr-10/rapport-fra-arbeidsgruppen-for-merittering-med-vedlegg.pdf https://www.uhr.no/temasider/karrierepolitikk/opprykksordninger/ https://www.uhr.no/_f/p1/i667c848f-8845-47e9-b8b6-fddfbde6782d/nasjonale_retningslinjer_vurdering_opprykk_professor_psykologi_npp_juni_2015.pdf https://lovdata.no/dokument/SF/forskrift/2018-09-12-1322 ...
