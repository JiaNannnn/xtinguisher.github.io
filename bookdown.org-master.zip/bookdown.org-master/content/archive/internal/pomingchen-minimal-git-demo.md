---
title: "Minimal-Git-demo"
author: "PoMingChen"
date: "2019-02-28T03:59:38Z"
tags: [Github]
link: "https://bookdown.org/PoMingChen/Minimal-Git-demo/"
length_weight: "9.3%"
pinned: false
---

This is a minimal example of Git service through GitHub and the GitHub Desktop. [...] 小瑜是一位社會人文科學相關主修的學生，學習上常常會需要寫報告，動則數千字到上萬字，以下是他管理檔案的方式，他承認有時候快被自己氣死…..會不會有時自己也這樣XD 截圖 後來，因緣際會地留意到Git這個東西，一套能夠讓開發者得以進行版本控制的程式。 往後用了Git之後，從此事半功倍好棒棒，檔案內容追蹤管理都方便許多，一起來瞧瞧Git到底是哪裡這麼厲害！ 與其他教材稍有不同的是，這本書規劃先從輕鬆的GitHub平台環境介紹開始，版本控制的學習則用圖形化介面（GUI）的GitHub Desktop實作來建立觀念，同時說明上嘗試以情境實作的方式來想像Git能 ...
