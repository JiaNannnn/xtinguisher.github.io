---
title: "Statistical Rethinking"
author: "Brynjólfur Gauti Jónsson"
date: "2018-12-18T22:41:49Z"
link: "https://bookdown.org/bgautijonsson/statistical_rethinking_solutions/"
length_weight: "8.4%"
pinned: false
---

These are solutions from the book by Richard McElreath. ...
