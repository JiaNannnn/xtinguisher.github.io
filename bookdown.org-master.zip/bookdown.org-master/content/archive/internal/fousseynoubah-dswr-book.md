---
title: "Data Science avec R"
author: "Fousseynou Bah"
date: "2019-03-18T15:56:41Z"
tags: [Data Science]
link: "https://bookdown.org/fousseynoubah/dswr_book/"
length_weight: "32.5%"
pinned: false
---

Data Science avec R [...] En décidant d’écrire un livre sur la data science, j’ai longuement débattu dans ma propre tête, je me suis posé plusieurs questions dont une qui revenait constamment: “a-t-on vraiment besoin d’un autre livre sur la data science?” “N’en-t-on pas assez?” Avec le succès dont jouit la discipline, ce n’est certainement pas les ressources qui manquent, aussi bien en ligne que dans les librairies. Et surtout, je me demandais bien “qu’avais-je à dire qui n’avait pas été dit”? Et pourtant, quelques raisons m’ont poussé à reconsidérer ma position. La première est assez égoïte.  ...
