---
title: "Data Science con R: Fundamentos y Aplicaciones"
author: "BEST: Behavioral Economics & Data Science Team"
date: "2019-02-04T13:12:06Z"
tags: [Data Science]
link: "https://bookdown.org/BEST/DSFA/"
length_weight: "10.1%"
repo: "BESTDATASCIENCE/DATA-SCIENCE-CON-R-FUNDAMENTOS-Y-APLICACIONES"
pinned: false
---

El mejor libro en espanol de ciencia de datos, libre y abierto. [...] Nota: El libro se encuentra en etapa de desarrollo. Este libro ha sido elaborado por BEST. Hace unos años el término Data Science no era tan conocido ni utilizado por la comunidad internacional, y menos aún local (Perú). En realidad, era un término usado rara vez por los estadísticos y algunos miembros de la computación científica. Y es que nuestra sociedad ha evolucionado, y con ellos ciertas necesidades. La Ciencia de Datos ha venido para quedarse, y en cualquier profesión (economistas, psicólogos, biólogos, ...
