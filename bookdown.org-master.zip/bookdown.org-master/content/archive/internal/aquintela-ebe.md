---
title: "Estadística Básica Edulcorada"
author: "Alejandro Quintela del Rio"
date: "2019-09-04T11:06:05Z"
link: "https://bookdown.org/aquintela/EBE/"
length_weight: "100%"
cover: "https://bookdown.org/aquintela/EBE/Figure/kimyon.png"
pinned: false
---

Estadística y probabilidad básica, con aplicaciones y elementos históricos. [...] Advertencia: Libro en fase de elaboración. No se recomienda copiar trozos, puesto que después podría haber lloros si hay acusaciones de plagio. La estadística para gente inteligente. Este libro está bajo licencia Creative Commons Attribution-NonCommercial-ShareAlike 4.0 International License. Los paquetes o librerías que se utilizan en este libro son las que siguen. Para ejecutar trozos de código particulares no habría que instalar todas, pero, si en algún momento la ejecución de algún ejemplo da error, podría ...
