---
title: "Tutorial SIG pour le diagnostic territorial"
author: "Tristan Berchoux (CIHEAM-IAMM)"
date: "2019-07-31T15:25:36Z"
tags: [Tutorial]
link: "https://bookdown.org/tristan_berchoux/tutorielsig/"
length_weight: "15.6%"
pinned: false
---

Tutoriel SIG pour le diagnostic territorial IAMM. [...] Suite aux cours magistraux, vous allez maintenant prendre en main un logiciel de “Système d’Information Géographique” libre et open source : QGIS. Tout au long du tutoriel, vous allez devoir effectuer des manipulations qui seront différenciées par un fond gris avec des questions correspondantes auxquelles vous devez répondre. Les données nécessaires pour effectuer le tutoriel sont à télécharger ICI.
Il vous est recommandé de sauvegarder votre projet (sous un nouveau nom) régulièrement Menu Projet → Sauvegarder sous... Les ordinateurs de ...
