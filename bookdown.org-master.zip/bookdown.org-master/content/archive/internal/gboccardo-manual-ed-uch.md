---
title: "RStudio para Estadística Descriptiva en Ciencias Sociales"
author: "Giorgio Boccardo Bosoni y Felipe Ruiz Bruzzone"
date: "2019-07-03T21:44:50Z"
link: "https://bookdown.org/gboccardo/manual-ED-UCH/"
length_weight: "34.4%"
pinned: false
---

RStudio para Estadística Descriptiva en Ciencias Sociales [...] En su segunda edición este libro fue editado en RStudio mediante RMarkdown y compilado usando el paquete Bookdown. Su ejecución se efectuó en una distribución del sistema operativo Linux de tipo Mint, específicamente en su actualización 19.1 “Tessa” y variante Cinnamon Edition. Para evitar algunos problemas derivados de la actualización del kernel de Linux se utilizó el software R en su versión 3.4.4, aunque a la fecha de su publicación, R ya había lanzado a su versión 3.6. Para evitar incongruencias entre algunas dependencias de  ...
