---
title: "R for marketing students"
author: "KU Leuven Marketing department"
date: "2019-05-11T10:20:02Z"
tags: [Market, Tutorial]
link: "https://bookdown.org/content/1340/"
length_weight: "36.2%"
pinned: false
---

KULeuven R tutorial for marketing students [...] In this tutorial, we will explore R as a tool to analyse and visualise data. R is a statistical programming language that has rapidly gained popularity in many scientific fields. The main difference between R and other statistical software like SPSS is that R has no graphical user interface. There are no buttons to click. R is run entirely by typing commands into a text interface. This may seem daunting, but hopefully by the end of this tutorial you will see how R can help you to do better statistical analysis. So why are we using R and not one  ...
