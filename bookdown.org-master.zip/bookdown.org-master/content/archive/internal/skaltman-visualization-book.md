---
title: "Visualization"
author: "Stanford Data Lab"
date: "2018-12-27T04:49:39Z"
tags: [Visualization, ggplot2]
link: "https://bookdown.org/skaltman/visualization-book/"
length_weight: "10.7%"
repo: "stanford-datalab/sara-dev/visualization"
pinned: false
---

This is a book on data visualization using ggplot2 created for the Stanford Data Challenge Lab. [...] This is a ...
