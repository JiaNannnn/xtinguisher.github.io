---
title: "數量方法（一）"
author: "林茂廷老師"
date: "2019-06-12T03:12:35Z"
link: "https://bookdown.org/tpemartin/econometric_analysis/"
length_weight: "23.3%"
pinned: false
---

數量方法（一）電子書 [...] 授課老師： 林茂廷
辦公室：社科大樓3F01
諮詢時間：TBA
電話：02﹣86741111轉67170
Email：mtlin@gm.ntpu.edu.tw ...
