---
title: "AWS Tutorial"
author: "Bingwei Liu"
date: "2019-08-09T20:07:14Z"
tags: [Tutorial, Package]
link: "https://bookdown.org/bingweiliu11/aws-tutorial-book/"
length_weight: "5.2%"
pinned: false
---

This is a minimal example of using the bookdown package to write a book. The output format for this example is bookdown::gitbook. ...
