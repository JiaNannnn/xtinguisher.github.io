---
title: "Notes for Nonparametric Statistics"
author: "Eduardo García Portugués"
date: "2019-08-26T09:17:34Z"
tags: [Statistics, Data Science, Course]
link: "https://bookdown.org/egarpor/NP-UC3M/"
length_weight: "100%"
cover: "https://bookdown.org/egarpor/NP-UC3M/images/figures/cover.png"
pinned: false
---

Notes for Nonparametric Statistics. MSc in Statistics for Data Science.
Carlos III University of Madrid. [...] Welcome to the notes for Nonparametric Statistics for the course 2018/2019. The subject is part of the MSc in Statistics for Data Science from Carlos III University of Madrid. The course is designed to have, roughly, one lesson per each main topic in the syllabus. The schedule is tight due to time constraints, which will inevitably make the treatment of certain methods a little superficial compared with what it would be the optimal. Nevertheless, the course will hopefully give you a ...
