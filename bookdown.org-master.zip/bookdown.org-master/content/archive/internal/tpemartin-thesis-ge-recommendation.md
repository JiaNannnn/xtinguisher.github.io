---
title: "通識課程推薦系統"
author: "蔡國梁"
date: "2018-06-01T08:29:40Z"
tags: [Github]
link: "https://bookdown.org/tpemartin/thesis_GE_recommendation/"
length_weight: "7.5%"
pinned: false
---

碩士論文 [...] 電子書網址： Github repo:https://github.com/tpemartin/thesis-GE-recommendation bookdown使用者說明 LyX 註冊RSconnect bookdown::publish_book()或bookdown::publish_book(account="帳戶名") ...
