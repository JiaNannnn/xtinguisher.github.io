---
title: "Kursmaterial till Certifierad Data Scientist"
author: "Ferrologic"
date: "2019-03-12T12:51:22Z"
tags: [Data Science]
link: "https://bookdown.org/content/2395/"
length_weight: "14.9%"
pinned: false
---

Det här dokumentet innehåller kursmaterial och övningar för det första blockets R-övningar. [...] För att ta del av det här materialet behöver du inte några särskilda förkunskaper. Övningarna och upplägget följer boken R for Data Science av Hadley Wickham och Garrett Grolemund som finns gratis. Den boken är ett utmärkt fördjupande komplement till det här ...
