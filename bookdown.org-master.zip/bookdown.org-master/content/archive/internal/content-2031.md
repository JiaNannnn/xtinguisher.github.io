---
title: "Arboles de decision y Random Forest"
author: "Johanna Orellana Alvear - johanna.orellana@ucuenca.edu.ec"
date: "2018-11-15T03:32:17Z"
link: "https://bookdown.org/content/2031/"
length_weight: "28.6%"
pinned: false
---

Arboles_de_decision_y_Random_Forest [...] “The key to artificial intelligence has always been the representation.” —Jeff Hawkins Aquí los detalles del curso . Aquí los datos que usaremos durante el curso. Breve recapitulación de R (Capítulo 2) Entorno de RStudio y ayuda (0.2 h) Directorios, scripts y librerías (0.3 h) Tipos de datos básicos y compuestos (0.5 h) Lectura y escritura de archivos (0.5 h) Indexación (1 h) Subconjuntos (1 h) Funciones (0.5 h) Arboles de Decisión - parte I Arboles de Decisión - parte II Random Forest - parte I Random Forest - parte ...
