---
title: "Data Science with R: A Resource Compendium"
author: "Martin Monkman"
date: "2019-09-04T03:47:46Z"
tags: [Data Science, Github, Package]
link: "https://bookdown.org/martin_monkman/DataScienceResources_book/"
length_weight: "27.1%"
repo: "MonkmanMH/DataScienceResources_book"
pinned: false
---

A modest and very incomplete listing of resources for tackling data science problems in R. [...] Draft This book grew out of my evergrowing collection of reference materials that was saved as an expanding array of markdown files in a github repo. By assembling it as a book, I hope that it will be more accessible and useful to other R users. The author would like to acknowledge everyone who has contributed to the books, articles, blog posts, and R packages cited within. License This work by Martin Monkman is licensed under a Creative Commons Attribution-NonCommercial-ShareAlike 2.5 Canada ...
