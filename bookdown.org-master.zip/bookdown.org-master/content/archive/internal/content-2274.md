---
title: "7 Agrupación de la información | Estadística y Machine Learning con R"
author: "Francisco Parra"
date: "2019-01-28T16:59:05Z"
tags: [Machine Learning]
link: "https://bookdown.org/content/2274/"
length_weight: "100%"
repo: "rstudio/bookdown-demo"
pinned: false
---

7 Agrupación de la información | Estadística y Machine Learning con R [...] Tanto las técnicas de reducción de dimensiones como las de agrupamiento, están basadas en determinar la semejanza (proximidad, similaridad) o disparidad (distancia, disimilaridad) existente; entre las variables las primeras, entre los individuos/variables las segundas. Lo primero a decidir será, pues, si optamos por centrar el análisis en medir disparidad o semejanza, lo cual dependerá en buena parte de los objetivos planteados en la investigación. Otra cuestión a considerar a la hora de optar por una medida u otra es  ...
