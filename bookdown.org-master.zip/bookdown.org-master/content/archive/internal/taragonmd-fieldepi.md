---
title: "Field Epidemiology with R"
author: "Tomás J. Aragón"
date: "2018-07-18T04:54:29Z"
tags: [Epidemiology, R Markdown, Package]
link: "https://bookdown.org/taragonmd/fieldepi/"
length_weight: "5.9%"
pinned: false
---

A book example for a Chapman & Hall book. [...] The document format “R Markdown” was first introduced in the knitr package (Xie, 2015, 2018) in early 2012. The idea was to embed code chunks (of R or other languages) in Markdown documents. In fact, knitr supported several authoring languages from the beginning in addition to Markdown, including LaTeX, HTML, AsciiDoc, reStructuredText, and Textile. Looking back over the five years, it seems to be fair to say that Markdown has become the most popular document format, which is what we expected. The simplicity of Markdown clearly stands out among ...
