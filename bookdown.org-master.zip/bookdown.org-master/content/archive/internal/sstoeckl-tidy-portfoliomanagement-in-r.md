---
title: "Tidy Portfoliomanagement in R"
author: "Sebastian Stöckl"
date: "2018-09-21T00:15:34Z"
tags: [Tidy]
link: "https://bookdown.org/sstoeckl/Tidy_Portfoliomanagement_in_R/"
length_weight: "23.6%"
pinned: false
---

First try on a book on tidy Portfolio Managment in R. [...] This book should accompany my lectures “Research Methods”, “Quantitative Analysis”, “Portoliomanagement and Financial Analysis” and (to a smaller degree) “Empirical Methods in Finance”. In the past years I have been a heavy promoter of the Rmetrics tools for my lectures and research. However, in the last year the development of the project has stagnated due to the tragic death of its founder Prof. Dr. Diethelm Würtz. It therefore happened several times that code from past semesters and lectures has stopped working and no more support  ...
