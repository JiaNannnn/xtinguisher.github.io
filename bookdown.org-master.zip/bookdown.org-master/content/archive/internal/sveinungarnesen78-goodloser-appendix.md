---
title: "The Good Loser"
author: "Peter Esaiasson, Sveinung Arnesen, and Hannah Werner"
date: "2019-05-13T12:38:03Z"
tags: [Conference]
link: "https://bookdown.org/sveinungarnesen78/Goodloser-appendix/"
length_weight: "38.4%"
pinned: false
---

The Good Loser [...] This is the analysis report for the Good Loser Project by Peter Esaiasson, Hannah Werner, and Sveinung Arnesen. The study comprises three survey embedded experiments; one video vignette experiment in Norway, one text vignette experiment in Sweden, and one conjoint experiment in Norway. The study has been presented at the Barcelona-Gothenburg-Bergen workshop on Experiments in Political Science in 2018, and will be presented at the 2019 Conference of the Midwestern Political Science Association in Chicago, USA. About Study I – Swedish vignette: TBA About Study II – ...
