---
title: "R och Demoskop"
author: "Filip Wastberg"
date: "2018-01-09T13:10:57Z"
link: "https://bookdown.org/filipwastberg/r-och-demoskop/"
length_weight: "13.8%"
repo: "rstudio/bookdown-demo"
pinned: false
---

Det här är ett dokument för att komma igång med R på Demoskop [...] Det här är ett dokument om R på Demoskop. R är ett programmeringsspråk för statistisk analys. På Demoskop används R i huvudsak som ett komplement till den programmering som vi gör SAS och SPSS. Det här dokumentet är anpassat efter våra arbetssätt på Demoskop. Några generella förkunskaper behövs inte. Däremot så rekommenderar vi att du efter att du gjort installationen gör den här kursen på datacamp.com. Det är enkel introduktion till R och några paket som underlättar arbetsflödet. Datacamp är en bra hemsida för att lära sig ...
