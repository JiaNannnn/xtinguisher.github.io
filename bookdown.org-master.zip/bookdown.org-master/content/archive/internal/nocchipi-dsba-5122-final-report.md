---
title: "DSBA-5122 Final Project"
author: "Nicholas Occhipinti, Karyn Cook, Ziyin Liu"
date: "2019-05-06T01:34:21Z"
link: "https://bookdown.org/nocchipi/dsba-5122-final_report/"
length_weight: "11.5%"
repo: "nick-occ/dsba_5122_final_project"
pinned: false
---

The final report for DSBA-5122 Final Project [...] For our project we explored data related to opioids, in an effort to better understand and obtain insight into the opioid epidemic. Our domain problem is one for a researcher wanting to explore the connection between prescriber rates of opioid prescriptions and opioid-related deaths both in the country as a whole and drilling down to the state level. The first part of the data we examined was prescriber data. This data would allow the researcher to see the distribution of opioid prescriptions across the US and also find the most commonly ...
