---
title: "Premier League Annual"
author: "Andrew Clark"
date: "2016-10-29T00:33:47Z"
tags: [Visualization]
link: "https://bookdown.org/aclark/PLAnnual2016/"
length_weight: "8.6%"
pinned: false
---

Premier League Annual [...] This is an ‘on the fly’ annual based on the 2016/17 Premier League season, updated weekly with charts, tables, highlight videos and trivia related to the games played. Each chapter features static visualizations relevant to the games that week. Greatly extended, fully-interactive and constantly updated versions can be found on the accompanying dashboard site Additional data is available at the Premier League Web site Most of the underlying data is unofficial, unguaranteed error-free and available for a million dollars. There is also likely to be use of James ...
