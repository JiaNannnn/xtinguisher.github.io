---
title: "Meu log de leitura de R for Data Science"
author: "Marcos V. C. Vital - LEQ-UFAL"
date: "2018-05-01T23:29:25Z"
tags: [Data Science, ggplot2]
link: "https://bookdown.org/marcosvital/meu_log_de_r4ds2/"
length_weight: "9.7%"
pinned: false
---

Meu log de leitura de R for Data Science [...] Se tem alguma pessoa que pode ser considerada um “pop star” do R, seria o Hadley Wickham: o cara é responsável pelo ggplot2 e pelo dplyr, que são alguns dos pacotes mais populares do R! Mas são justamente pacotes que eu quase não uso… :( Deixe eu explicar melhor. Eu sou usuário do R há muitos anos (fiz as contas de cabeça enquanto eu escrevo, e se não me enganei, agora em 2018 seriam uns 13 ou 14 anos!), então já tem um bocado de tempo que aprendi a como resolver (e ensinar) algumas coisas. Até aí tudo bem. Acontece que o Hadley trouxe uma ...
