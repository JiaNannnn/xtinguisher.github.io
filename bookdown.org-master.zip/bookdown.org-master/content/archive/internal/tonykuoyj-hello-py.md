---
title: "Hello Py: Python 程式設計"
author: "Pyradise"
date: "2018-05-14T08:16:53Z"
tags: [Python]
link: "https://bookdown.org/tonykuoyj/hello-py/"
length_weight: "13.4%"
pinned: false
---

Pyradise 是專注於 Python 教學的團隊，致力於分享學習經驗，推廣資料科學，人工智慧，讓更多人能參與到這波資訊與人工智慧的學習浪潮。 專注於技術，熱衷於教學的開發者，希望透過教學，傳遞出更多想法的帽子哥。 資料科學與推廣教育的愛好者，閒暇時喜歡長跑與乒乓球；是 2017 iT邦幫忙鐵人賽 Big Data 組冠軍。 前端工程師與設計師。 ...
