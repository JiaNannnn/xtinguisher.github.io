---
title: "Preguntas entrevistas Data Science"
author: "Sergio Berdiales"
date: "2019-05-30T20:53:25Z"
tags: [Data Science, Github]
link: "https://bookdown.org/sergioberdiales/preguntas_entrevistas_data_science/"
length_weight: "6.6%"
pinned: false
---

Preguntas entrevistas Data Science [...] En estas notas trato de responder a diferentes preguntas que un candidato para una posición de Data Scientist se puede encontrar en una entrevista. Muchas de las preguntas vienen directamente de artículos sobre este tema específico (enlaces en la sección ‘02-Referencias’), otras de mi experiencia personal y otras de aportaciones de otras personas. Aquí enlazo una Google sheet con las preguntas que voy recopilando. Si tienes alguna pregunta interesante y quieres añadirla al listado, adelante. Este es el repositorio en github: https://github.com/sergiober ...
