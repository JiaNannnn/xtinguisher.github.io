---
title: "Notas sobre Estimación Puntual"
author: "Peter Olejua"
date: "2017-04-06T23:37:14Z"
link: "https://bookdown.org/peterolejua/estimacion_puntual/"
length_weight: "7.5%"
repo: "rstudio/Notas-estimacion-puntual"
pinned: false
---

Se desarrolla el tema de estimación puntual para el curso Métodos en Bioestadística I perteneciente al Maestría en Bioestadística de la Universidad Javeriana [...] En las siguientes páginas se desarrolla brevemente el tema de estimación puntual. Forma parte de una evaluación para el curso Métodos en Bioestadística I, perteneciente al Maestría en Bioestadística de la Universidad Javeriana. Este trabajo puede usado como una introducción, a manera de notas de clases o como un inicio de colaboración a un escrito más amplio y completo sobre estimación puntual. Cualquier crítica, aporte y/o ...
