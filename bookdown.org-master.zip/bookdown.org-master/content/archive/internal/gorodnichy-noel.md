---
title: "Bilingual Christmas songs"
author: "gorodnichy"
date: "2019-01-29T02:24:52Z"
link: "https://bookdown.org/gorodnichy/Noel/"
length_weight: "14.5%"
pinned: false
---

A compilation of Christmas song favourites for multi-lingual families, with chords [...]  ...
