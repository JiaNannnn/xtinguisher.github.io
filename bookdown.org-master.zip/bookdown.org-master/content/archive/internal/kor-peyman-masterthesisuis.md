---
title: "Decision-Driven Data Analytics for Well Placement Optimization in Field Development Scenario - Powered by Machine Learning"
author: "Peyman Kor"
date: "2019-07-04T16:56:33Z"
tags: [Machine Learning, Package, Github]
link: "https://bookdown.org/kor_peyman/masterthesisuis/"
length_weight: "22.9%"
repo: "Peymankor/thesis"
pinned: false
---

This is a minimal example of using the bookdown package to write a book. The output format for this example is bookdown::gitbook. [...] Submitted in accordance with the requirements for the degree of Master of Science (M.Sc)in Petroleum EngineeringUniversity of Stavanger, Energy Resources Department The data, source code and algorithem of this thesis can be found in the author’s Github. Your feedback and comments will be appreciated and the author could be reached out via Linkedin, twitter. This thesis is licensed under Attribution-NonCommercial-ShareAlike 4.0 ...
