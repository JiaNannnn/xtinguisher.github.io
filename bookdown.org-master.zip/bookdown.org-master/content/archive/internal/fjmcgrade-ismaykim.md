---
title: "ModernDive"
author: "Chester Ismay and Albert Y. Kim STARRING FRANK MCGRADE"
date: "2017-08-23T02:41:21Z"
tags: [Textbook, Statistics, Data Science, Course, R Programming]
link: "https://bookdown.org/fjmcgrade/ismaykim/"
length_weight: "40%"
repo: "ismayc/moderndiver-book"
pinned: false
---

An open-source and fully-reproducible electronic textbook bridging the gap between traditional introductory statistics and data science courses. [...] Help! I’m new to R and RStudio and I need to learn about them! However, I’m completely new to coding! What do I do? If you’re asking yourself this question, then you’ve come to the right place! Start with our Introduction for Students. This is version 0.2.0 of ModernDive published on August 02, 2017. For previous versions of ModernDive, see Section 1.4. This book assumes no prerequisites: no algebra, no calculus, and no prior programming/coding  ...
