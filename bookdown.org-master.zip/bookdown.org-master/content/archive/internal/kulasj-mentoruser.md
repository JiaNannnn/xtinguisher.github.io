---
title: "MSU I-O Student Mentorship Program User Manual"
author: "Eagle I-O"
date: "2019-09-04T21:11:06Z"
tags: [Psychology]
link: "https://bookdown.org/kulasj/mentoruser/"
length_weight: "8.6%"
cover: "https://bookdown.org/kulasj/mentoruser/images/cover.png"
pinned: false
---

This is a Users Manual for the Montclair State University I-O Psychology student mentorship program. The intended users are: 1) mentors, 2) protege’s, 3) Eagle I-O consultants, and 4) MSU I-O program faculty members. [...] This manual was written in Bookdown using the GitBook ...
