---
title: "GerminaQuant"
author: "Flavio Lozano Isla, Omar Benites Alfaro, Marcelo Francisco Pompelli"
date: "2016-10-11T05:33:53Z"
tags: [Guide, Shiny, Package]
link: "https://bookdown.org/flavjack/GermBook/"
length_weight: "8.2%"
cover: "https://bookdown.org/flavjack/GermBook/img/germinaquant.png"
repo: "Flavjack/GermBook"
pinned: false
---

A guide for analisis of germination variables and usage of GerminaQuant. [...] GerminaQuant allows make the calculation of the germination variables incredibly easy in an interactive applications build in R (R Core Team 2016), based in GerminaR and Shiny (Chang et al. 2016) package. GerminaQuant app is reactive!. Outputs change instantly as users modify inputs, without requiring a reload the app. The principal features of the application allow calculate the princiapal germination Variables, statistical analysis and easy way to plot the results.  ...
