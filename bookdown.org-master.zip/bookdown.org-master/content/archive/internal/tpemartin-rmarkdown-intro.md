---
title: "R Markdown 介紹"
author: "林茂廷老師"
date: "2017-12-27T09:19:07Z"
tags: [R Markdown]
link: "https://bookdown.org/tpemartin/rmarkdown_intro/"
length_weight: "6.1%"
pinned: false
---

dplyr 介紹 [...] 一個標準化的純文字語法（syntax），用來表達豐富的排版意境。 Wiki範例 本身不會產生word, html或pdf檔，而是透過其他應用程式，如pandoc，來進一步生成相關文件格式。 ...
