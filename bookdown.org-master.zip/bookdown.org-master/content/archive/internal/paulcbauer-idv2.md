---
title: "Interactive Data Visualization (2nd Day)"
author: "Paul C. Bauer & Richard Traunmüller"
date: "2016-11-23T00:14:07Z"
tags: [Visualization, Shiny, Tutorial]
link: "https://bookdown.org/paulcbauer/idv2/"
length_weight: "20.4%"
pinned: false
---

Script developed for a workshop at the CUSO doctoral school on the 4th and 5th November 2016. [...] This document serves as slides and script for the second day of the workshop Data Visualization taught by Paul C. Bauer and Richard Traunmüller for the Programme doctoral en science politique (PDSPO) (Bern, 4-5 of November 2016). The present material is licensed under a Creative Commons Attribution-ShareAlike License 3.0. Regarding further use of this material contact Paul. Some of the material is inspired by the official shiny tutorial and Plotly for R by Carston Sievert. For potential future ...
