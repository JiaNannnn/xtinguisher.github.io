---
title: "Data Science and Visualizations with R"
author: "Jonathan Wong"
date: "2017-07-16T15:20:29Z"
tags: [Data Science, Visualization, Course, Tidyverse, Package]
link: "https://bookdown.org/datavizsolutions/02-dplyr/"
length_weight: "6%"
pinned: false
---

Data Science and Visualizations with R [...] This is a course on the use of tidyverse packages tidyverse provides a complete suite of modern data-handling tools. It is an essential toolbox for any data scientist using R. The tidyverse package is designed to be easy to install. This course will dive into using tidyverse. It will assume you have already installed r and rstudio and how some familiarity on how to use the rstudio. This book will use the nycflights13 dataset This package contains information about all flights that departed from NYC in 2013: 336,776 flights with 16 variables. To ...
