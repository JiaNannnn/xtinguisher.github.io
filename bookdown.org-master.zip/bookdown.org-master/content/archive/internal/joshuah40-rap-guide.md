---
title: "RAP Guide for ONS"
author: "Joshua & Catrin"
date: "2019-06-03T12:51:55Z"
tags: [Guide, Course, Package]
link: "https://bookdown.org/joshuah40/RAP_guide/"
length_weight: "16.2%"
repo: "rstudio/bookdown-demo"
pinned: false
---

This is a guide for RAP at the ONS [...] The aim of this guide to provide a guide for RAP at the ONS. This is meant to be a more comprehsive guide for RAP at the ONS aimed at those newer to coding and is a suppliment to the RAP Companion and RAP course on Udemy. These materials are excellent and provide an in-depth look at RAP in R. what the point of the guide, it’s relationship to the RAP course/companion any conventions defintions Note: we refer to our package on GitLab as a ‘project’ throughout, however this can be interchanged with the term ‘repository’. Terminology - We refer to Git ...
