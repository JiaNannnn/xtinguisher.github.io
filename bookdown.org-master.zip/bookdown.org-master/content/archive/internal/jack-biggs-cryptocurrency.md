---
title: "Introduction to Digital Currency"
author: "J.W.Biggs"
date: "2018-05-12T09:48:15Z"
tags: [Digital Currency, Package]
link: "https://bookdown.org/Jack_Biggs/Cryptocurrency/"
length_weight: "13.7%"
repo: "rstudio/bookdown-demo"
pinned: false
---

A summary of research conducted hitherto. [...] This is research I have conducted for personal use. Using the bookdown package has enabled me to piece together my research in a quick and neat manner. I have tried to convey complex terms as simply as possible utilizing visual examples where I can. Constructive criticism is welcomed - I will regularly be updating this ...
