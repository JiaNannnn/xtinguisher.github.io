---
title: "Tank Guide"
author: "Marina Wiebe"
date: "2019-04-27T18:33:58Z"
tags: [Guide]
link: "https://bookdown.org/marinawiebe/TankGuide/"
length_weight: "7.4%"
pinned: false
---

This is a book regarding how to take care of my tank [...] So, you’ve been tasked with taking care of your girlfriend’s hobby tank. It’s a pretty thing and it looks easy enough, but what’s all involved? This book will give you an idea of the tank buddies, tools, and ...
