---
title: "Steem Handbook"
author: "Steem 中文社区集体创作"
date: "2019-03-30T13:47:23Z"
link: "https://bookdown.org/steem_guides/steemh/"
length_weight: "100%"
repo: "steem-guides/steem-guides"
pinned: false
---

Steem Handbook [...] 本书的编写和维护需要长久的贡献，大门永远敞开，欢迎加入我们。你可以： 贡献本书缺失的内容； 修改已有内容； 修改错别字； 其他任何跟书稿编写有关的工作。 向本书项目投稿的方法见附录16。 主编：@dapeng 副主编： @maiyude 顾问（按字母顺序）：@deanliu @jademont @lemooljiang @oflyhigh @rivalhw @sweetsssj @tumutanzi 编剧： @maiyude 封面设计： @maiyude 本书的各章作者、编辑、校对见各章节脚注。待书稿完成后，名单将汇总在这里。 ...
