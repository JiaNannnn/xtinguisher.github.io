---
title: "Descenso Internacional del Sella"
author: "Sergio Berdiales"
date: "2019-08-17T16:25:24Z"
link: "https://bookdown.org/sergioberdiales/descenso_del_sella/"
length_weight: "9.8%"
pinned: false
---

En este libro voy publicando mis notas sobre el Descenso Internacional del Sella. De momento solo he explorado los tiempos de los ganadores absolutos de la prueba, es decir, del K2 ...
