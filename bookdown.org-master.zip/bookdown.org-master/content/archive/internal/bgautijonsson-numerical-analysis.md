---
title: "Numerical Analysis: Notes"
author: "Brynjólfur Gauti Jónsson"
date: "2018-02-23T22:26:58Z"
tags: [Numerical Analysis, Package, Course]
link: "https://bookdown.org/bgautijonsson/numerical_analysis/"
length_weight: "7.1%"
pinned: false
---

This is a minimal example of using the bookdown package to write a book. The output format for this example is bookdown::gitbook. [...] This is a collection of my notes and algorithms from a course on Numerical Analysis at the University of Iceland. The book used in the course was Numerical Analysis by Timothy ...
