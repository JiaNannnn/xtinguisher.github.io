---
title: "Sosyal Bilimler R Platformu"
author: "Burak AYDIN, James ALGINA, Walter LEITE, Hakan ATILGAN"
date: "2018-02-27T13:38:23Z"
link: "https://bookdown.org/burak2358/SARP-TR/"
length_weight: "35.1%"
cover: "https://bookdown.org/burak2358/SARP-TR/images/coverpicture.png"
repo: "burakaydin/SARP"
pinned: false
---

Sosyal Bilimler R Platformu [...] Bu platformun hakları korunmuştur CC0 by Burak AYDIN. Bu materyal İngilizce olarak hazırlanıp Türkçeye çevirilmiştir. Bu platform sosyal bilimler alanında çalışan ve nicel veri analizlerinin teoriden ziyade uygulama aşamasına ilgi gösteren araştırmacılar için oluşturulmuştur. Bütün istatistiksel prosedürler R (R Core Team 2016b) ile yürütülmüş, gerçek veri kullanımına özen gösterilmiştir. Bu materyale platform denilmesinin üç sebebi vardır, (a) katkıya açıktır,(b) dinamik bir içeriğe sahiptir, (c) bilgisayar anakartı gibi kullanılabilir, R ile oluşturulmuş ...
