---
title: "Chess Encounters"
author: "Andrew Clark and Joshua Kunst"
date: "2016-08-10T19:05:30Z"
link: "https://bookdown.org/aclark/chess/"
length_weight: "6.3%"
cover: "https://bookdown.org/aclark/chess/images/cover_fixed.png"
pinned: false
---

Chess Encounters [...]  ...
