---
title: "R Studio: A 3D Printer for Business Analytics"
author: "Ed Anderson"
date: "2017-08-06T13:33:16Z"
tags: [Business Analytics]
link: "https://bookdown.org/twoshotamericano/thesisfinal2/"
length_weight: "15.5%"
repo: "rstudio/bookdown-demo"
pinned: false
---

This document describes the concept of Mass Customisation as it applies to Business Analytics and provides case study implementations of R Studio [...] Good Morning! How are you doing? It’s been great being part of the Analytical Community the last few years hasn’t it? The excitement is everywhere about “big-data”,“data-science”,“MOOCs”. I have been blown away by the talent being attracted into Analytics.One current trend is ‘a shift from a desire to work for bigger name brand companies like Facebook or Google, to more mission-driven organizations attempting to make an impact on society. ...
