---
title: "tmdlTools Guide"
author: "Elise Hinman"
date: "2019-09-12T18:30:34Z"
tags: [Guide, Package]
link: "https://bookdown.org/ehinman/tmdlToolsGuide/"
length_weight: "11.2%"
pinned: false
---

A step by step guide to using the R package, tmdlTools [...] This guide walks watershed coordinators through installing R and its associated packages on their computer. If you still have questions about running R or the tmdlTools app, Elise Hinman is available and happy to assist you.  ...
