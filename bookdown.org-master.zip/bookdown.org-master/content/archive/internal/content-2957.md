---
title: "Réalisation de Mini Projets R"
author: "content"
date: "2019-09-10T15:43:00Z"
tags: [Tidyverse]
link: "https://bookdown.org/content/2957/"
length_weight: "24.4%"
repo: "https://github.com/LamineDiamban/BlogDiamban.git"
pinned: false
---

Site DIAMBAN Lamine bookdown::gitbook. [...] Ce blog est un mémoire qui regroupe quelques uns des projets que je réalise en statistique spécialement en R et Tidyverse. En effet, étudiant en M2 Statistique et Science des données à l’IM2AG de Grenoble, j’ai eu à effectuer divers projets dans le cadre de ma formation. Mais aussi, par pur passion et afin de mieux consolider mes connaissances, j’aime appliquer la science des statistiques dans mes domaines d’intérêt.
Il est vrai qu’en dehors de mes études, j’ai une passion pour les nouvelles technologies, le sport, le cinéma notamment les courts ...
