---
title: "Guide til klinikophold"
author: "Søren O’Neill"
date: "2017-11-01T15:07:59Z"
tags: [Guide]
link: "https://bookdown.org/sorenspam50/guide/"
length_weight: "17.5%"
pinned: false
---

Denne side tjener som vejledning og inspiration til supervisorer og studerende på den præ-graduate, kliniske uddannelse på klinisk biomekanik. [...] På disse sider finder du vejledning til de præ-graduate kliniskeophold for kiropraktor-studerende (stud. kand.manu) De præ-graduate klinikophold er opdelt som illustreret herover; med et præ-klinisk kursus på SDU efterfulgt af en ‘clinic-entrance’ eksamen, et længere ophold på rygcenter og 2 mindre ophold i andre regi. Teksten er opdelt i to hovedsektioner – én som primært er skrevet med supervisorerne for øje og én for studerende. Begge ...
