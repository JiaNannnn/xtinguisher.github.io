---
title: "统计学习方法 – 基于R的算法实现"
author: "lcrfromfzu@qq.com"
date: "2018-04-08T01:57:51Z"
tags: [Package]
link: "https://bookdown.org/lyuchengrui/statisticallearningmethods/"
length_weight: "36.3%"
pinned: false
---

This is a minimal book created by using the bookdown package. The output format for this little book is bookdown::gitbook. [...] 本文档的发布依赖于bookdown包, 对作者表示感谢! 文档所写R代码的依据算法来源于统计学习方法(李航著), 对作者表示感谢! 文档章节内容具体包括: ...
