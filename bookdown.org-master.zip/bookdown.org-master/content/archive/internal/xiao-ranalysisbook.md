---
title: "R 数据分析指南与速查手册"
author: "郭晓"
date: "2019-05-26T04:32:11Z"
tags: [数据分析, 笔记]
link: "https://bookdown.org/xiao/RAnalysisBook/"
length_weight: "28.9%"
pinned: false
---

这是郭晓的R数据分析笔记本。 [...] 郭晓，北京大学电子学2018届硕士。数据分析从业者，R语言、机器学习持续精进学习中。爱好知识的整理、挖掘与应用。 联系方式：xiaoguodata@126.com ...
