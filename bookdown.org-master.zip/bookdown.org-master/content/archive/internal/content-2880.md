---
title: "Introduction to R"
author: "Filip Wästberg"
date: "2019-09-17T17:28:05Z"
tags: [Package]
link: "https://bookdown.org/content/2880/"
length_weight: "33.3%"
pinned: false
---

This book contains workshop material for 4 workshop held at tele2 during the autumn of 2019 [...] During the workshops you will use R on both a cloud platform and on your own computer. If you have a previous R version installed on your computer we recommend that you update both R and RStudio. This book is written in R with the package bookdown built by Yihui Xie. You can find out more about bookdown ...
