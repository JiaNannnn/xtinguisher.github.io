---
title: "IsoriX: Isoscape Computation and Inference of Spatial Origins using R"
author: "The IsoriX core Team"
date: "2018-09-07T20:16:09Z"
tags: [Package]
link: "https://bookdown.org/content/782/"
length_weight: "18.9%"
repo: "courtiol/IsoriX"
pinned: false
---

This book is the official documentation for the R package IsoriX. [...] This new documentation of the R package IsoriX which aims at replacing the former vignettes and will ultimately provide much more information than before. The chapters 1 to 5 are almost complete but you will have to wait for the other chapters to follow.  ...
