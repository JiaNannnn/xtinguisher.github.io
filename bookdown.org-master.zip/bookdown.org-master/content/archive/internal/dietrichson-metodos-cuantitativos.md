---
title: "Métodos Cuantitativos"
author: "Aleksander Dietrichson, PhD"
date: "2019-09-22T13:22:12Z"
link: "https://bookdown.org/dietrichson/metodos-cuantitativos/"
length_weight: "27.1%"
repo: "dietrichson/metodos_cuantitativos"
pinned: false
---

Material de Cátedra para el curso «Metodologías cuantitativas». [...] Este texto ha sido editado en respuesta a la aparente falta de un libro de texto introductorio al análisis cuantitativo y estadísticas acesible y moderno en castellano. Si bien fue concebido como material de cátedra para Metodologías cuantitativas materia que dicta el autor en la Escuela de Humanidades de la Universidad Nacional San Martín, se adaptará fácilmente a cursos introductorios de estadísticas en ...
