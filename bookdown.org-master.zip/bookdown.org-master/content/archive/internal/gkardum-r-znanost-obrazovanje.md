---
title: "R - u znanosti i obrazovanju"
author: "Goran Kardum"
date: "2019-06-10T09:27:38Z"
link: "https://bookdown.org/gkardum/r_znanost_obrazovanje/"
length_weight: "5.9%"
repo: "gkardum/r-u-znanosti"
pinned: false
---

R - u znanosti [...] NAPOMENA: Tekst je u izradi (nije lektoriran i provjeren do kraja, nisu povezani svi literaturni navodi!) Knjiga je namijenjena svima koji žele naučiti modele obrade i prikaza podataka pomoću R jezika koristeći aplikaciju RStudio. Knjiga nije samo vodič kroz R jezik i RStudio aplikaciju, već koristi brojne izvore informacija te usporedbe različitih metoda koje se koriste u društvenim, humanističkim i biomedicinskim znanostima. Tako, ovdje možemo pronaći usporedbe različitih eksplanatornih i konfirmatornih metoda s brojnim referencijama te modeliranje (SEM). Ovo djelo nije  ...
