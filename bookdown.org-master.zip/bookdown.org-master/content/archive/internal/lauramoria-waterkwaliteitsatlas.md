---
title: "Waterkwaliteit in beeld"
author: "Laura Moria"
date: "2018-12-14T13:34:51Z"
link: "https://bookdown.org/lauramoria/waterkwaliteitsAtlas/"
length_weight: "7.9%"
pinned: false
---

Waterkwaliteit in beeld [...] De informatie over de huidige situatie en ontwikkelingen van het aquatisch ecosysteem in de regio Amstel, Gooi en Vechtstreek bundelen wij in een zogenaamde Atlas met thema kaarten. Onze doelstellingen en de huidige ecologische kwaliteit zijn verbeeld in de afbeeldingen hieronder. In hoofdstuk 2 staan kaarten van verschillende indicatoren van ecologische kwaliteit voor de Habitatrichtlijn (Natura2000) en de Kaderrichtlijn water. Naast de ontwikkeling van de ecologische toestand wordt ook verbeeld welke processen deze toestand bepalen op een andere pagina ...
