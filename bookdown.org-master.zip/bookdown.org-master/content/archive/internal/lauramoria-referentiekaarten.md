---
title: "Referentiekaarten"
author: "Laura Moria"
date: "2018-12-18T09:34:54Z"
link: "https://bookdown.org/lauramoria/referentiekaarten/"
length_weight: "3.9%"
pinned: false
---

Referentiekaarten [...] Voor de KRW is een groot deel van het oppervlaktewater aangewezen als waterlichaam. Een waterlichaam is een “onderscheiden oppervlaktewater van aanzienlijke omvang, zoals een meer, een rivier of een kanaal”. Voor deze wateren moet de toestand van het aquatisch ecosysteem beschreven worden. Onder oppervlaktewateren van “aanzienlijke omvang” vallen waterlichamen met een minimale oppervlakte van 0,5 km2 of een stroomgebied tussen de 10 en 100 km2. In onderstaande afbeelding staan de KRW waterlichamen in het beheergebied van AGV. In de Kaderrichtlijn Water (KRW) is een ...
