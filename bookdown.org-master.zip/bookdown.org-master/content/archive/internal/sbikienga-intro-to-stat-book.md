---
title: "Econ 215 Notes"
author: "Salfo Bikienga"
date: "2016-09-26T19:43:46Z"
tags: [Statistics, Course]
link: "https://bookdown.org/sbikienga/Intro_to_stat_book/"
length_weight: "23.6%"
pinned: false
---

Lecture notes for my introduction to statistics class at University of Nebraska-Lincoln. [...] This is supposed to be your first course in statistics. So the goal is to give you an overview of what statistics is, why it is a powerful thing to know, how you can use it to make informed decision or understand “numbers speak” people throw around in the news. At the end of this class, I hope: 1- You understand the importance of statistics; 2- You can better appreciate the numbers you get from the news; 3- You can perform your own analysis to inform yourself, and your collaborators. The explosion ...
