---
title: "認識 R 的美好"
author: "郭耀仁"
date: "2018-05-12T01:37:34Z"
tags: [Python, Market]
link: "https://bookdown.org/tonykuoyj/eloquentr/"
length_weight: "19.3%"
pinned: false
---

是郭耀仁，資料科學與推廣教育的愛好者，喜歡使用 R 語言與 Python 做資料科學應用，在台大資工系統訓練班開設多門 R 語言與 Python 的相關課程，亦與企業合作提供客製化的內訓課程；同時也是一個超棒的中文資料科學專欄 DataInPoint 的主編；這個專欄與波士頓的資料科學教學團隊 DataCamp 有行銷合作（Affiliate Marketing）。 如果您有 R 語言、Python、資料科學、教學、專案或顧問的需求，可以 email 與我聯絡：tonykuoyj@gmail.com R 語言是一個高階的統計程式語言，她在 2017 IEEE 調查中排名位於第 6 名，1是以資料分析為主要目的程式語言中的最高位。其他熟為人知的像是 Matlab 排名在第 15 名、SQL 排名在第 23 名、 Julia ...
