---
title: "国内任天堂 Switch 使用情况与玩家需求调查报告"
author: "OldNin"
date: "2019-08-30T01:20:34Z"
link: "https://bookdown.org/CoLin00/_switch_/"
length_weight: "11.1%"
cover: "https://bookdown.org/CoLin00/_switch_/image/cover.png"
pinned: false
---

国内任天堂 Switch 玩家的小调查。 [...] Nintendo Switch™1是日本任天堂公司出品的电子游戏机，于2017年3月3日发售。2019年4月26日，腾讯宣布将与任天堂合作，在中国代理发售任天堂 Switch 主机。28月2日，腾讯携手任天堂的 Nintendo Switch 首度亮相第十七届中国国际数码互动娱乐展览会（ChinaJoy 2019），并于上午在上海浦东香格里拉大酒店举办了主题为“奇乐同享，‘任’式好游戏”的媒体见面会。3 2019年8月12日，我通过个人微博、百度贴吧（NS吧和Switch吧，帖子不幸被隐藏）、QQ群、微信群、抽屉新热榜（帖子有幸被小编推上热榜）和IT之家（获得几个用户回复）这几个平台发放了问卷填写链接。8月13日，问卷填写链接被知任CHS、NS新闻速报和黑桐谷歌等媒体和大博主转发后，问卷回 ...
