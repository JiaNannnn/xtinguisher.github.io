---
title: "Basic Social Justice Orientations scale testing"
author: "Cristóbal Moya"
date: "2018-08-24T05:50:49Z"
tags: [Package, Statistics]
link: "https://bookdown.org/cristobalmoya/reproducibility_bsjo/"
length_weight: "14.8%"
pinned: false
---

This is a minimal example of using the bookdown package to write a book. The output format for this example is bookdown::gitbook. [...] The original publication has three tables where ALLBUS-2014 is used: The following analysis are focused on the first two tables (Table 15 and Table 8), because they contain the main resutls regarding this data source and the table from supplementary materials should not matter as long as factor loadings in Table 8 are correct. The descriptive statistics of the eight items displayed in Table 15 of the original article are reproduced from the article’s website ...
