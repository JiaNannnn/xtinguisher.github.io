---
title: "The Open Quant Live Book"
author: "OpenQuants.com"
date: "2019-09-03T02:44:51Z"
tags: [Data Analysis, Machine Learning, Guide]
link: "https://bookdown.org/souzatharsis/open-quant-live-book/"
length_weight: "21.8%"
cover: "https://bookdown.org/souzatharsis/open-quant-live-book/./fig/cover.jpg"
repo: "souzatharsis/open-quant-live-book"
pinned: false
---

The Open Quant Live Book [...] The book aims to be an Open Source introductory reference of the most important aspects of financial data analysis, algo trading, portfolio selection, econophysics and machine learning in finance with an emphasis in reproducibility and openness not to be found in most other typical Wall Street-like references. The Book is Open and we welcome co-authors. Feel free to reach out or simply create a pull request with your contribution! See project structure, guidelines and how to contribute here. First published at: openquants.com. Licensed under Attribution-NonCommer ...
