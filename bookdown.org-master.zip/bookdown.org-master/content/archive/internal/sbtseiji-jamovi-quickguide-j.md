---
title: "jamoviクイックガイド（Analysis編）"
author: "芝田 征司"
date: "2019-04-09T05:33:44Z"
link: "https://bookdown.org/sbtseiji/jamovi_quickguide_J/"
length_weight: "23.7%"
pinned: false
---

本書はjamoviのAnalysisモードの簡易ガイドです。jamoviのAnalysisモードに含まれるメニュー項目およびその設定項目について，簡単な説明を加えています。 [...] 本書はjamoviのAnalysisモードを使用するための簡易ガイドです。メニューに含まれる項目やその設定項目について，簡単な説明を加えています。本書の内容の大部分は，jamoviと同じ分析をRで実行するためのパッケージ「jmv」のリファレンスをもとにしています。 本書は統計法の教科書としてではなく，（英語の苦手な学生たちが）jamoviを使って分析をする際のヘルプとして作成されています。統計そのものについてはすでに一定の知識がある，あるいは統計の授業や教科書で ...
