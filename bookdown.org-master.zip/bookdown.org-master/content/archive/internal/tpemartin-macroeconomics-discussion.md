---
title: "Macroeconomics"
author: "Mau-Ting Lin"
date: "2018-06-19T01:55:08Z"
tags: [Macroeconomics, Visualization, Github]
link: "https://bookdown.org/tpemartin/Macroeconomics_discussion/"
length_weight: "18.4%"
repo: "tpemartin/Macroeconomics"
pinned: false
---

This is a collection of the discussion lists from Macroeconomics. [...] The theory contents will follow 1 closely. Item 2 is for data visualization. And item 3 is for general discussion regarding world news. https://goo.gl/kbQwP5 Class participation and quizzes: 10% Midterm Exam: 30% Final Exam: 30% Others Rhttp://www.r-project.org/ RStudiohttp://rstudio.org/ Github desktophttps://desktop.github.com/ ...
