---
title: "Supplement to Shiny in Production"
author: "kellobri.github.io"
date: "2019-01-15"
tags: [Shiny]
link: "https://kellobri.github.io/shiny-prod-book/"
length_weight: "9.3%"
pinned: false
---

This document is full of supplemental resources and content from the Shiny in Production Workshop delievered at rstudio::conf 2019.  ...
