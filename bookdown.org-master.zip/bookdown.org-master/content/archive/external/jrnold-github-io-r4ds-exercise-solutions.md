---
title: "R for Data Science: Exercise Solutions"
author: "Jeffrey B. Arnold"
date: "2019-09-01"
tags: [Data Science, Github]
link: "https://jrnold.github.io/r4ds-exercise-solutions/"
length_weight: "26.9%"
repo: "jrnold/r4ds-exercise-solutions"
pinned: false
---

Solutions to the exercises in “R for Data Science” by Garrett Grolemund and Hadley Wickham. [...] If you find any typos, errors, or places where the text may be improved, please let me know. The best ways to provide feedback are by GitHub or hypothes.is annotations. Opening an issue or submitting a pull request on GitHub Adding an annotation using hypothes.is. To add an annotation, select some text and then click the on the pop-up menu. To see the annotations of others, click the in the upper right-hand corner of the page. This book contains the exercise solutions for the book R for Data ...
