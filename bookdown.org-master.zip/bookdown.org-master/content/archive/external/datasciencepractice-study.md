---
title: "Data Science Practice"
author: "Perry Stephenson"
date: ""
tags: [Data Science, Course]
link: "https://datasciencepractice.study/"
length_weight: "38.1%"
cover: "https://datasciencepractice.study/images/cover.png"
pinned: false
---

Course notes for 94692 Data Science Practice at the University of Technology, Sydney. [...] This website forms the course notes for
94692 Data Science
Practice which is an
elective subject developed as part of the Master of Data Science and
Innovation
program at the University of Technology, Sydney.
For more information about this subject see the Subject Information. For more
information about the MDSI program see the MDSI
Prospectus. Whilst these course materials have been produced specifically for MDSI
students, they have been made available under a permissive
license for the benefit of the  ...
