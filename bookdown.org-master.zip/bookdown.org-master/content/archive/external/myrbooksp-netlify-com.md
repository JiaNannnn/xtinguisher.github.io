---
title: "Aprender R: iniciación y perfeccionamiento"
author: "François Rebaudo"
date: "2019-04-10"
tags: [Github]
link: "https://myrbooksp.netlify.com/"
length_weight: "18.4%"
cover: "https://myrbooksp.netlify.com/myFigures/cover.png"
repo: "frareb/myRBook_SP"
pinned: false
---

Un guía para adquirir las bases de la programación con R y conducir de forma efectiva su gestión y análisis de datos. [...] Este libro está diseñado para actualizarse de acuerdo con las nuevas características de R y según la disponibilidad de sus colaboradores. Es un libro de colaboración, así que siéntase libre de compartir sus comentarios o colaborar directamente para mejorarlo. Si tiene algún comentario, sugerencia o si identifica errores, no dude en enviarme un correo electrónico (francois.rebaudo@ird.fr), o si está familiarizado con GitHub en el sitio web del proyecto ...
