---
title: "mixOmics vignette"
author: "Kim-Anh Le Cao1, Sebastien Dejean2, Al J Abadi3"
date: ""
tags: [Package, Course]
link: "https://mixomicsteam.github.io/Bookdown/"
length_weight: "11.3%"
repo: "mixOmicsTeam/mixOmics"
pinned: false
---

Vignette for the R package mixOmics [...] This document outlines the use of our key functions in our mixOmics package. If you run into any issues reproducing these results, please let us know by creating an issue here. We welcome transparent discussions and suggestions, feel free to on our new mixOmics Discourse forum! This document outlines the use of our key functions in our mixOmics package. If you run into any issues reproducing these results, please let us know by creating an issue here. We welcome transparent discussions and suggestions, feel free to share your own on our new mixOmics ...
