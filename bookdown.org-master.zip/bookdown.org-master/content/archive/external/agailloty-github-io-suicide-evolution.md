---
title: "Overview of suicide in the world"
author: "Axel-Cleris Gailloty"
date: "2019-05-17"
tags: [Package]
link: "https://agailloty.github.io/suicide-evolution/"
length_weight: "5.3%"
pinned: false
---

Overview of suicide in the world [...] According to the WHO Suicides organization, 800.000 committed suicide in 2018. This means every 40 seconds a person dies by suicide. This number is fortunately dropping. In this kernel I want to explore the evolution of suicide rate using the dataset provided here on Kaggle. I’ll be using the powerful R language to do this analysis, my main focus is to understand what affects the suicide rate to decrease. Let’s start by loading the packages we’ll be using throughout this study. Before we go further in this analysis, it is important to know what each ...
