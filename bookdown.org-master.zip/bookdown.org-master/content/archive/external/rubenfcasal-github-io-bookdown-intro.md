---
title: "Escritura de libros con bookdown"
author: "Fernández-Casal, R. y Cotos-Yáñez, T.R."
date: "2018-10-28"
tags: [Github]
link: "https://rubenfcasal.github.io/bookdown_intro/"
length_weight: "8.4%"
repo: "rubenfcasal/bookdown_intro"
pinned: false
---

Este libro es una introducción al paquete bookdown para la escritura de libros (en castellano, galego, …). [...] Este libro es una pequeña guía sobre como emplear el paquete bookdown de R para la escritura de libros, incluyendo algunos detalles de configuración para la escritura en otros idiomas distintos del inglés (castellano, galego,…). Este mismo libro ha sido escrito en R-Markdown empleando el paquete bookdown y está disponible en el repositorio Github: rubenfcasal/bookdown_intro. Para generar el libro (compilar) puede ser recomendable instalar la última versión de RStudio y la versión ...
