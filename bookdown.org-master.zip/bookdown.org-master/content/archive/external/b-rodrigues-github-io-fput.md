---
title: "Functional programming and unit testing for data munging with R"
author: "Bruno Rodrigues"
date: "2017-12-28"
tags: [Functional Programming, Unit Test, R Programming]
link: "https://b-rodrigues.github.io/fput/"
length_weight: "17.1%"
repo: "b-rodrigues/fput"
pinned: false
---

This book is an introduction to functional programming and unit testing with the R programming language, for the purpose of data muning [...] This book is still being written, some chapters are not finished yet, and there might be (there are) some typos. Don’t hesitate to write to me if you notice something weird. You can purchase a digital copy of this book at leanpub. The version on Leanpub will not always be up-to-date, I only update it when I made very big changes (new chapters, etc). But once this book will be finished, both version are going to be the same. This book serves to show how ...
