---
title: "APS 135: Introduction to Exploratory Data Analysis with R"
author: "Dylan Z. Childs"
date: "2019-02-03"
tags: [Exploratory Data Analysis, Course]
link: "https://dzchilds.github.io/eda-for-bio/"
length_weight: "24%"
repo: "dzchilds/eda-for-bio"
pinned: false
---

Course book for Introduction to Exploratory Data Analysis with R (APS 135) in the Department of Animal and Plant Sciences, University of Sheffield. [...] This is the online course book for the Introduction to Exploratory Data Analysis with R component of APS 135, a module taught by the Department and Animal and Plant Sciences at the University of Sheffield. You can view this book in any modern desktop browser, as well as on your phone or tablet device. Dylan Childs is running the course this year. Please email him if you spot any problems with the course book. You will be introduced to the R ...
