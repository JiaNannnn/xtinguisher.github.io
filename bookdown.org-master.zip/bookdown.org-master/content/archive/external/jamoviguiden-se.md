---
title: "jamoviguiden"
author: "Jonas Rafi"
date: "2019-09-24"
tags: [Guide]
link: "https://jamoviguiden.se/"
length_weight: "7.3%"
repo: "jRafi/jamoviguiden"
pinned: false
---

Lär dig göra independent samples t-test, paired samples t-test, one sample t-test, ANOVA, repeated measures ANOVA, factorial ANOVA, mixed ANOVA, linear regression, och logistic regression i jamovi. jamoviguiden innehåller även avsnitt om csv-filer och skalnivåer. [...] Jamoviguiden innehåller korta, lättillgängliga guider (med bilder!) över vanliga procedurer i jamovi.
För att hålla innehållet kort så beskrivs inget (eller lite) om antaganden bakom statistiska tester eller hur resultaten ska tolkas. När du väl kommit igång är det ofta enkelt att utforska vidare på egen hand. Vill du lära dig ...
