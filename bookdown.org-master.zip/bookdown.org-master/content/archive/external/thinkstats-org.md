---
title: "ThinkStats - a tale of two books"
author: ""
date: ""
link: "https://thinkstats.org/"
length_weight: "5.3%"
pinned: false
---

 It was subsequently brought to his attention that there already existed a book called “ThinkStats” by Allen Downey. In order to prevent confusion between the two books, Dr. Poldrack’s book can now be found at statsthinking21.org.  ...
