---
title: "Se former au logiciel R : initiation et perfectionnement"
author: "François Rebaudo"
date: "2019-06-27"
tags: [Guide, Github]
link: "https://myrbookfr.netlify.com/"
length_weight: "36.7%"
cover: "https://myrbookfr.netlify.com/myFigures/cover.png"
repo: "frareb/myRBook_FR"
pinned: false
---

Un guide pour acquérir les bases de la programmation avec R et conduire efficacement la gestion et l’analyse de ses données. [...] Ce livre est mis à jour régulièrement, alors n’hésitez pas à consulter les dernières modifications ci-dessous. Si vous avez des commentaires, des suggestions ou si vous identifiez des erreurs, n’hésitez pas à m’envoyer un email (francois.rebaudo@ird.fr), ou si vous connaissez GitHub sur le site du projet (https://github.com/frareb/myRBook_FR). Ce livre est collaboratif, il repose sur votre participation. Ce livre est également disponible en espagnol ...
