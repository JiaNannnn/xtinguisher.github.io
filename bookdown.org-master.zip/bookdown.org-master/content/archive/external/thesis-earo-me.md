---
title: "Tidy tools for supporting fluent workflow in temporal data analysis"
author: "Earo Wang"
date: ""
tags: [Tidy, Data Analysis]
link: "https://thesis.earo.me/"
length_weight: "15.4%"
pinned: false
---

This is the website for my PhD thesis at Monash University (Australia), titled “Tidy tools for supporting fluent workflow in temporal data analysis”. ...
