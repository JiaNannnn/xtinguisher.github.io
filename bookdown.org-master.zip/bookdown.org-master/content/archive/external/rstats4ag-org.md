---
title: "Statistical Analysis of Agricultural Experiments using R"
author: "Andrew Kniss & Jens Streibig"
date: ""
link: "https://rstats4ag.org/"
length_weight: "35.1%"
cover: "https://rstats4ag.org/Rstats4agLogo76px.png"
pinned: false
---

This is a first attempt at creating a printable version of Rstats4ag.org. [...] Kniss AR, Streibig JC (2018) Statistical Analysis of Agricultural Experiments using R. http://Rstats4ag.org ...
