---
title: "useR! Machine Learning Tutorial"
author: "Erin LeDell"
date: "2018-04-05"
tags: [Machine Learning, Tutorial]
link: "https://koalaverse.github.io/machine-learning-in-R/"
length_weight: "14.8%"
repo: "rstudio/bookdown-demo"
pinned: false
---

useR! 2016 Tutorial: Machine Learning Algorithmic Deep Dive. [...] useR! 2016 Tutorial: Machine Learning Algorithmic Deep Dive This tutorial contains training modules for six popular supervised machine learning methods: Here are some practical, related topics we will cover for each algorithm: Instructions for how to install the necessary software for this tutorial is available here. Data for the tutorial can be downloaded… Certain algorithms don’t scale well when there are millions of features. For example, decision trees require computing some sort of metric (to determine the splits) on all ...
