---
title: "Data Visualization"
author: "Kieran Healy"
date: ""
tags: [Visualization]
link: "https://socviz.co/"
length_weight: "0%"
cover: "https://socviz.co/assets/dv-cover-executive-b.jpg"
pinned: true
---

A practical introduction. [...] Published by Princeton University Press. Incomplete draft. This version: 2018-04-25. You should look at your data. Graphs and charts let you explore and
learn about the structure of the information you collect. Good data
visualizations also make it easier to communicate your ideas and
findings to other people. Beyond that, producing effective plots from
your own data is the best way to develop a good eye for reading and
understanding graphs—good and bad—made by others, whether
presented in research articles, business slide decks, public policy
advocacy, or ...
