---
title: "Field Guide to the R Ecosystem"
author: "Mark Sellors"
date: "2018-08-19"
tags: [Guide]
link: "https://fg2re.sellorm.com/"
length_weight: "10.6%"
repo: "sellorm/field-guide-to-the-r-ecosystem"
pinned: false
---

This guide aims to introduce the reader to the main elements of the R ecosystem. [...] This work is licensed under a Creative Commons Attribution 4.0 International ...
