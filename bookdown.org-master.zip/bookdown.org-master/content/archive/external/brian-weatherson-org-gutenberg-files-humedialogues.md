---
title: "Dialogues Concerning Natural Religion"
author: "David Hume"
date: "1779-01-01"
tags: [Package]
link: "https://brian.weatherson.org/gutenberg-files/humedialogues/"
length_weight: "0%"
pinned: false
---

David Hume’s Dialogues Concerning Natural Religion [...] Original text from Project Gutenberg. This eBook is for the use of anyone anywhere at no cost and with almost no restrictions whatsoever. You may copy it, give it away or re-use it under the terms of the Project Gutenberg License included with this eBook or online at http://www.gutenberg.net. This page is created using the Tufte package within Bookdown. Both were written by primarily by Yihue Xie. Pamphilus to Hermippius It has been remarked, my HERMIPPUS, that though the ancient philosophers
conveyed most of their instruction in the ...
