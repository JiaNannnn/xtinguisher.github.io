---
title: "Predictive Models: Explore, Explain, and Debug"
author: "Przemyslaw Biecek and Tomasz Burzykowski"
date: "2019-09-24"
tags: [Predictive Model, Visualization]
link: "https://pbiecek.github.io/PM_VEE/"
length_weight: "19.7%"
repo: "pbiecek/PM_VEE"
pinned: false
---

This book introduces key concepts for exploration, explanation and visualization of complex predictive models. [...]  ...
