---
title: "Clustered Data"
author: "Michael Clark m-clark.github.io"
date: "2018-09-16"
link: "https://m-clark.github.io/clustered-data/"
length_weight: "10%"
repo: "m-clark/clustered-data"
pinned: false
---

This document provides a brief comparison of various approaches to dealing with clustered data situations. [...]  ...
