---
title: "Odds & Ends"
author: "Jonathan Weisberg"
date: ""
tags: [Textbook, Course]
link: "https://jonathanweisberg.org/vip/"
length_weight: "5.3%"
cover: "https://jonathanweisberg.org/vip/img/social_image.png"
repo: "jweisber/vip"
pinned: false
---

An open access textbook for introductory philosophy courses on probability and inductive logic. [...] This textbook is for introductory philosophy courses on probability and inductive logic. It is based on a typical such course I teach at the University of Toronto, where we offer “Probability & Inductive Logic” in the second year, alongside the usual deductive logic intro.\(\,\) The book assumes no deductive logic. The early chapters introduce the little that’s used. In fact almost no formal background is presumed, only very simple high school algebra. Several well known predecessors inspired  ...
