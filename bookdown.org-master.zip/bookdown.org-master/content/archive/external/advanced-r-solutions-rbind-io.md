---
title: "Advanced R Solutions"
author: "Malte Grosser, Henning Bumann & Hadley Wickham"
date: ""
tags: [Advanced R, Github]
link: "https://advanced-r-solutions.rbind.io/"
length_weight: "24.3%"
cover: "https://advanced-r-solutions.rbind.io/images/advrs_cover.png"
repo: "Tazinho/Advanced-R-Solutions"
pinned: false
---

Solutions to the Exercises from Hadley Wickham’s book ‘Advanced R’. [...] This book offers solutions to the exercises from Hadley Wickham’s book Advanced R (Edition 2). It is work in progress and under active development. The 2nd edition of Advanced R is still being revised, but we hope to provide most of the answers in 2019. The solutions to the first edition of Advanced R can currently be found at https://advanced-r-solutions-ed1.netlify.com/. The code for this book can be found on GitHub. Your PRs and suggestions are very welcome. This work by Malte Grosser and Henning Bumann is licensed ...
