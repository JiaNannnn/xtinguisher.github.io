---
title: "Physik Libre"
author: "Michael A. Rundel, et al."
date: "2019-09-01"
link: "https://physikbuch.schule/"
length_weight: "100%"
repo: "not-available-yet"
pinned: false
---

Freies Physikbuch für die Sekundarstufe II ...
