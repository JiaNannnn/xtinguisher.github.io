---
title: "POSEIDON tutorial"
author: "Ernesto Carrella"
date: "2018-11-19"
tags: [Tutorial, Guide]
link: "https://carrknight.github.io/poseidon/tutorial/"
length_weight: "10.1%"
pinned: false
---

This is a basic tutorial on how to use POSEIDON and set it up to explore basic fishery problems. I try to cover everything that does not require changing any of the Java code [...] This is a simple tutorial on using POSEIDON, a fishery agent-based model.
You can read more about this project by reading its main paper or looking at the code repository. This guide will not explain or require any analysis of the java code. I try here to simply show what can be done by just using the graphical user interface and basic text ...
