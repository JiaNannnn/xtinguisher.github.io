---
title: All books on bookdown.org
---

Below is a list of books written with **bookdown**, including those published to bookdown.org (books without substantial content are excluded) and a few hosted on external servers. The books are ordered roughly by date. An asterisk `*` after a date indicates the date is unknown, which often means a `date` field is missing in the YAML metadata of the source document `index.Rmd`. The list of books is automatically generated. For more information (including how to add or remove your books on this page), please see the [About](/about/) page.
