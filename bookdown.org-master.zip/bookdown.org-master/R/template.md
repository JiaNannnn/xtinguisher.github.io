---
title: "{{{title}}}"
author: "{{{authors}}}"
date: "{{{date}}}"
{{#tags}}tags: {{{tags}}}
{{/tags}}link: "{{{url}}}"
length_weight: "{{{length_weight}}}"
{{#cover}}cover: "{{{cover}}}"
{{/cover}}{{#repo}}repo: "{{{repo}}}"
{{/repo}}pinned: {{{pinned}}}
---

{{{description}}}
